#!/usr/bin/env python3
"""Recalculate redacted numeric evidence; does not reverify private identities."""
import argparse, gzip, importlib.util, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('frozen_statistics', ROOT/'frozen/summarize.py')
stats = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stats)


def numeric_reader(metadata, rows):
    """Build the frozen estimator's data input without invented identity hashes."""
    labels = [metadata['baseline'], metadata['candidate']]
    stats.require(len(set(labels)) == 2, 'distinct labels required')
    cases = metadata['cases']; by_id = {c['id']: c for c in cases}
    stats.require(len(by_id) == len(cases), 'duplicate case')
    counts = {'measured': metadata['rounds'], 'warmup': metadata['warmups'],
              'alloc': metadata['allocation_rounds']}
    rounds = {p: list(range(-n, 0) if p == 'warmup' else range(n)) for p, n in counts.items()}
    phases = {p: {} for p in counts if counts[p]}
    for index, row in enumerate(rows, 1):
        stats.require(row['source_row'] == index, 'source row order changed')
        phase, cid, label, r = (row[k] for k in ('phase', 'case', 'variant', 'round'))
        stats.require(phase in phases and cid in by_id and label in labels and r in rounds[phase], 'unknown row key')
        key = (cid, r, label)
        stats.require(key not in phases[phase], 'duplicate row')
        stats.require(sorted(row['pair_order']) == sorted(labels), 'invalid pair order')
        for name in stats.ALLOCATION_METRICS if phase == 'alloc' else stats.TIMING_METRICS:
            stats.finite_number(stats.field(row, name), name)
        phases[phase][key] = row
    for phase, phase_rows in phases.items():
        stats.require(len(phase_rows) == len(cases)*counts[phase]*2, 'incorrect row count')
        for cid in by_id:
            first = []
            for r in rounds[phase]:
                pair = [phase_rows[(cid, r, label)] for label in labels]
                stats.require(pair[0]['pair_order'] == pair[1]['pair_order'], 'pair order differs')
                order = pair[0]['pair_order']
                indices = [phase_rows[(cid, r, label)]['source_row'] for label in order]
                stats.require(indices[1] == indices[0]+1, 'pair members not adjacent')
                first.append(order[0])
            if phase == 'measured':
                stats.require(abs(first.count(labels[0])-first.count(labels[1])) <= 1, 'unbalanced AB/BA')
    return {'labels': labels, 'cases': cases, 'phases': phases, 'phase_rounds': rounds,
            'ignored_preflight_rows': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    args = parser.parse_args()
    metadata = json.loads((args.run/'metadata.json').read_text())
    with gzip.open(args.run/'samples.jsonl.gz', 'rt') as f: rows = [json.loads(line) for line in f]
    # Only the input validator is replaced. The exact frozen estimator,
    # bootstrap draws, distributions, ratios and aggregates are unchanged.
    stats.validate = numeric_reader
    result = stats.public_summary(stats.summarize(metadata, rows,
        metadata['bootstrap_resamples'], metadata['bootstrap_seed']))
    result['validation'] = {'status': 'numeric pairing and completeness passed',
        'rows': len(rows), 'private_input_or_svg_identity_reverified': False,
        'scope': 'Redacted numeric data only; local identity claims are separate evidence.'}
    expected = json.loads((args.run/'summary.json').read_text())
    for key in ('method', 'cases', 'groups', 'tags', 'comparison', 'baseline', 'candidate'):
        if result[key] != expected[key]: raise ValueError('Recalculation differs: '+key)
    print(json.dumps({'run': args.run.name, 'rows': len(rows), 'all_published_numeric_statistics_exact': True,
        'private_input_or_svg_identity_reverified': False}))

if __name__ == '__main__': main()
