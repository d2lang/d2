package routing

import (
	"context"
	"errors"
	"fmt"
	"maps"
	"testing"

	"github.com/d2lang/d2/d2layouts/d2talalayout/internal/layoutgraph"
	"github.com/d2lang/d2/lib/geo"
)

type usedPortsFixture struct {
	router         *ovgEdgeRouter
	source, target *layoutgraph.Node
	from, to       *OVGNode
	sourceCluster  map[*layoutgraph.Node]bool
	targetCluster  map[*layoutgraph.Node]bool
}

func newUsedPortsFixture(t *testing.T) *usedPortsFixture {
	t.Helper()
	source := layoutgraph.NewNode(1, 10, 10)
	target := layoutgraph.NewNode(2, 10, 10)
	otherSource := layoutgraph.NewNode(3, 10, 10)
	otherTarget := layoutgraph.NewNode(4, 10, 10)
	from := NewOVGNode(geo.NewPoint(0, 0))
	to := NewOVGNode(geo.NewPoint(100, 0))
	s1 := NewOVGNode(geo.NewPoint(1, 0))
	s2 := NewOVGNode(geo.NewPoint(2, 0))
	t1 := NewOVGNode(geo.NewPoint(99, 0))
	t2 := NewOVGNode(geo.NewPoint(98, 0))
	ovg := NewOVG(nil)
	ovg.Ports[source] = []*OVGNode{s1, s2}
	ovg.Ports[target] = []*OVGNode{t1, t2}
	route := func(a, b *layoutgraph.Node, nodes ...*OVGNode) *Route {
		return &Route{GEdge: layoutgraph.NewEdge(a, b), OVGNodes: nodes,
			FromPort: *nodes[0].Point, ToPort: *nodes[len(nodes)-1].Point}
	}
	duplicate := route(source, target, s1, t1)
	incoming := route(otherSource, target, s2, t2)
	outgoing := route(source, otherTarget, s2, t2)
	reverse := route(target, source, t2, s2)
	unrelated := route(otherSource, otherTarget, s1, t1)
	guard, err := newRouteSearchWorkGuard(context.Background(), Default, maxRouteSearchWorkUnits)
	if err != nil {
		t.Fatal(err)
	}
	return &usedPortsFixture{
		router: &ovgEdgeRouter{ovg: ovg, work: guard, pointToRoute: map[geo.Point][]*Route{
			*from.Point: {duplicate, incoming, reverse, unrelated},
			*to.Point:   {duplicate, outgoing},
		}},
		source: source, target: target, from: from, to: to,
		sourceCluster: map[*layoutgraph.Node]bool{source: true, otherSource: true},
		targetCluster: map[*layoutgraph.Node]bool{target: true, otherTarget: true},
	}
}

func (f *usedPortsFixture) call(ctx context.Context, undesirable bool) ([6]map[geo.Point]bool, error) {
	a, b, c, d, e, g, err := f.router.usedPorts(ctx, f.source, f.target, f.from, f.to, f.sourceCluster, f.targetCluster, undesirable)
	return [6]map[geo.Point]bool{a, b, c, d, e, g}, err
}

func expectedUsedPorts(undesirable bool) [6]map[geo.Point]bool {
	m := [6]map[geo.Point]bool{
		{{X: 1}: true, {X: 2}: true},
		{{X: 99}: true, {X: 98}: true},
		{{X: 1}: true},
		{{X: 99}: true},
		{{X: 1}: true, {X: 2}: true},
		{{X: 99}: true, {X: 98}: true},
	}
	if undesirable {
		m[4], m[5] = map[geo.Point]bool{}, map[geo.Point]bool{}
	}
	return m
}

func requireUsedPortMaps(t *testing.T, got, want [6]map[geo.Point]bool) {
	t.Helper()
	for i := range got {
		if got[i] == nil || !maps.Equal(got[i], want[i]) {
			t.Fatalf("map %d = %v, want nonnil %v", i, got[i], want[i])
		}
	}
}

func TestUsedPortsScratchRepeatedCallsAndIndependence(t *testing.T) {
	f := newUsedPortsFixture(t)
	for i, m := range f.router.usedPortMaps {
		if m != nil {
			t.Fatalf("map %d allocated before first usedPorts call", i)
		}
	}
	other := newUsedPortsFixture(t)
	otherMaps, err := other.call(context.Background(), false)
	if err != nil {
		t.Fatal(err)
	}
	for _, undesirable := range []bool{false, true, false} {
		got, err := f.call(context.Background(), undesirable)
		if err != nil {
			t.Fatal(err)
		}
		requireUsedPortMaps(t, got, expectedUsedPorts(undesirable))
		// Deliberately leave each map dirty. The next invocation must clear all
		// six, and one map/router must never share another's scratch storage.
		for i, m := range got {
			point := geo.Point{X: float64(1000 + i), Y: 7}
			m[point] = false
			for j := range got {
				if _, found := got[j][point]; j != i && found {
					t.Fatalf("map %d aliases map %d", i, j)
				}
				if _, found := otherMaps[j][point]; found {
					t.Fatalf("map %d aliases another router's map %d", i, j)
				}
			}
		}
	}
	f.router.pointToRoute = nil
	got, err := f.call(context.Background(), false)
	if err != nil {
		t.Fatal(err)
	}
	for i, m := range got {
		if m == nil || len(m) != 0 {
			t.Fatalf("empty invocation map %d = %v", i, m)
		}
	}
}

func TestUsedPortsScratchCancellationPartialRetry(t *testing.T) {
	f := newUsedPortsFixture(t)
	ctx := &cancelWhenOVGChanges{Context: context.Background(), shouldCancel: func() bool {
		for _, m := range f.router.usedPortMaps {
			if len(m) == 0 {
				return false
			}
		}
		return true
	}}
	if err := f.router.bindWork(ctx); err != nil {
		t.Fatal(err)
	}
	got, err := f.call(ctx, false)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("error = %v, want cancellation after all six maps were populated", err)
	}
	for i, m := range got {
		if m != nil || len(f.router.usedPortMaps[i]) == 0 {
			t.Fatalf("map %d: returned %v, retained partial %v", i, m, f.router.usedPortMaps[i])
		}
	}
	if f.router.work.used == 0 {
		t.Fatal("canceled before any accounted work")
	}
	if err := f.router.bindWork(context.Background()); err != nil {
		t.Fatal(err)
	}
	// Different inputs on the retry expose stale partial state from cancellation.
	f.router.pointToRoute = nil
	start := f.router.work.used
	got, err = f.call(context.Background(), true)
	if err != nil {
		t.Fatal(err)
	}
	for i, m := range got {
		if m == nil || len(m) != 0 {
			t.Fatalf("retry map %d retains canceled state: %v", i, m)
		}
	}
	if delta := f.router.work.used - start; delta != 2 {
		t.Fatalf("empty retry accounted %d work, want the original two endpoint visits", delta)
	}
}

func TestUsedPortsScratchOversizedRetention(t *testing.T) {
	for _, size := range []int{0, 1, 127, 128, 512} {
		t.Run(fmt.Sprint(size), func(t *testing.T) {
			f := newUsedPortsFixture(t)
			f.router.pointToRoute = nil
			var old [6]map[geo.Point]bool
			for i := range old {
				old[i] = make(map[geo.Point]bool)
				for k := 0; k < size; k++ {
					old[i][geo.Point{X: float64(k), Y: float64(i)}] = true
				}
				f.router.usedPortMaps[i] = old[i]
			}
			got, err := f.call(context.Background(), false)
			if err != nil {
				t.Fatal(err)
			}
			for i, m := range got {
				if m == nil || len(m) != 0 {
					t.Fatalf("map %d was not reset: %v", i, m)
				}
				if size >= 128 && len(old[i]) != size {
					t.Fatalf("oversized map %d was cleared before being discarded", i)
				}
				point := geo.Point{X: -1, Y: float64(i)}
				old[i][point] = true
				if _, retained := m[point]; retained != (size < 128) {
					t.Fatalf("size %d map %d retained = %v", size, i, retained)
				}
			}
		})
	}
}

// legacyUsedPorts preserves the pre-reuse implementation as a test-only oracle.
// It checks result contents and exact work/cancellation behavior independently
// of the scratch map lifecycle added to the production function.
func (router *ovgEdgeRouter) legacyUsedPorts(
	ctx context.Context,
	gSource, gTarget *layoutgraph.Node,
	source, target *OVGNode,
	sourceClusterNodes, targetClusterNodes map[*layoutgraph.Node]bool,
	undesirableClusterArrangement bool,
) (map[geo.Point]bool, map[geo.Point]bool, map[geo.Point]bool, map[geo.Point]bool, map[geo.Point]bool, map[geo.Point]bool, error) {
	sourcePortsUsed := make(map[geo.Point]bool)
	targetPortsUsed := make(map[geo.Point]bool)
	duplicateSourcePortsUsed := make(map[geo.Point]bool)
	duplicateTargetPortsUsed := make(map[geo.Point]bool)
	sharedClusterSourcePortsUsed := make(map[geo.Point]bool)
	sharedClusterTargetPortsUsed := make(map[geo.Point]bool)

	for _, node := range []*OVGNode{source, target} {
		if err := router.work.step(); err != nil {
			return nil, nil, nil, nil, nil, nil, err
		}
		// we might process the same route, but since it's just assigning to maps, it's fine
		for _, route := range router.pointToRoute[*node.Point] {
			if err := router.work.step(); err != nil {
				return nil, nil, nil, nil, nil, nil, err
			}
			if (route.GEdge.From != gSource) && (route.GEdge.To != gSource) && (route.GEdge.From != gTarget) && (route.GEdge.To != gTarget) {
				continue
			}

			// note ports of duplicate connections
			if (route.GEdge.From == gSource) && (route.GEdge.To == gTarget) {
				duplicateSourcePortsUsed[route.FromPort] = true
				duplicateTargetPortsUsed[route.ToPort] = true
			}

			// If we're going to or coming from a cluster, then we penalize going through port nodes which
			// are not shared by other nodes of the cluster, which has the effect of making cluster nodes share
			// routes
			// ClusterPortSharing Step 1.
			// we want the same port if a cluster route has the same source or target so record it here
			if !undesirableClusterArrangement {
				if route.GEdge.To == gTarget {
					if _, is := sourceClusterNodes[route.GEdge.From]; is {
						sharedClusterTargetPortsUsed[route.ToPort] = true
					}
				}
				if route.GEdge.From == gSource {
					if _, is := targetClusterNodes[route.GEdge.To]; is {
						sharedClusterSourcePortsUsed[route.FromPort] = true
					}
				}
			}

			for _, routeNode := range route.OVGNodes {
				if err := router.work.step(); err != nil {
					return nil, nil, nil, nil, nil, nil, err
				}
				for _, portNode := range router.ovg.Ports[gSource] {
					if err := router.work.step(); err != nil {
						return nil, nil, nil, nil, nil, nil, err
					}
					if routeNode == portNode {
						sourcePortsUsed[*portNode.Point] = true
						break
					}
				}
				for _, portNode := range router.ovg.Ports[gTarget] {
					if err := router.work.step(); err != nil {
						return nil, nil, nil, nil, nil, nil, err
					}
					if routeNode == portNode {
						targetPortsUsed[*portNode.Point] = true
						break
					}
				}
			}
		}
	}
	if err := checkEdgeRoutingCanceled(ctx); err != nil {
		return nil, nil, nil, nil, nil, nil, err
	}
	return sourcePortsUsed, targetPortsUsed, duplicateSourcePortsUsed, duplicateTargetPortsUsed, sharedClusterSourcePortsUsed, sharedClusterTargetPortsUsed, nil
}

type usedPortsCountingContext struct {
	context.Context
	calls    int
	cancelAt int
}

func (ctx *usedPortsCountingContext) Err() error {
	ctx.calls++
	if ctx.cancelAt > 0 && ctx.calls >= ctx.cancelAt {
		return context.Canceled
	}
	return nil
}

func TestUsedPortsScratchMatchesLegacyWorkAndCancellation(t *testing.T) {
	for _, undesirable := range []bool{false, true} {
		full := newUsedPortsFixture(t)
		if _, err := full.call(context.Background(), undesirable); err != nil {
			t.Fatal(err)
		}
		// Visit every local work limit and every context poll through a complete
		// traversal, including cancellation after partial map writes.
		for _, mode := range []string{"work-limit", "cancellation"} {
			for stop := 0; stop <= int(full.router.work.used)+3; stop++ {
				t.Run(fmt.Sprintf("undesirable=%t/%s/%d", undesirable, mode, stop), func(t *testing.T) {
					current, legacy := newUsedPortsFixture(t), newUsedPortsFixture(t)
					currentCtx := &usedPortsCountingContext{Context: context.Background()}
					legacyCtx := &usedPortsCountingContext{Context: context.Background()}
					if mode == "work-limit" {
						current.router.work.limit = uint64(stop)
						legacy.router.work.limit = uint64(stop)
					} else {
						currentCtx.cancelAt = stop
						legacyCtx.cancelAt = stop
					}
					// The helper is called after search binds its context; binding itself is
					// unchanged and is not part of the usedPorts work being compared here.
					current.router.work.ctx = currentCtx
					current.router.work.done = nil
					legacy.router.work.ctx = legacyCtx
					legacy.router.work.done = nil
					got, gotErr := current.call(currentCtx, undesirable)
					a, b, c, d, e, f, wantErr := legacy.router.legacyUsedPorts(legacyCtx, legacy.source, legacy.target, legacy.from, legacy.to, legacy.sourceCluster, legacy.targetCluster, undesirable)
					want := [6]map[geo.Point]bool{a, b, c, d, e, f}
					if fmt.Sprint(gotErr) != fmt.Sprint(wantErr) {
						t.Fatalf("error %v, legacy %v", gotErr, wantErr)
					}
					if current.router.work.used != legacy.router.work.used || currentCtx.calls != legacyCtx.calls {
						t.Fatalf("work/polls=%d/%d, legacy=%d/%d", current.router.work.used, currentCtx.calls, legacy.router.work.used, legacyCtx.calls)
					}
					for i := range got {
						if (got[i] == nil) != (want[i] == nil) || !maps.Equal(got[i], want[i]) {
							t.Fatalf("map %d=%v, legacy=%v", i, got[i], want[i])
						}
					}
				})
			}
		}
	}
}
