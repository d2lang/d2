# Go A/B measurements

Comparison: incremental. 14 cases; 10 measured paired rounds; 3 allocation paired rounds.

All samples passed exit, timeout, paired-round, identity, and exact SVG checks. Only preflight-success cases in this selected run are represented; consult the local preflight report for excluded or failed cases.

Ratios are candidate / baseline; lower values indicate lower resource use. Brackets show 95% paired percentile bootstrap intervals (2,000 resamples; seed 20260914). Whole round blocks are shared across cases. Intervals are unadjusted for multiple comparisons and describe these fixed cases. An interval containing 1 is inconclusive. These results make no automatic keep/drop decision.

Allocation counters come from separate instrumented runs. Peak RSS is process memory. Public and private groups are reported separately; the all-cases result is descriptive and does not substitute for either group.

## Group wall time

| Group | Cases | Baseline total ms | Candidate total ms | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | ---: | ---: | ---: | --- | --- |
| public | 10 | 2,836.818 | 2,832.113 | 0.998 [0.995, 1.008] | 0.998 [0.995, 1.005] |
| private | 4 | 1,459.800 | 1,458.939 | 0.999 [0.989, 1.007] | 0.998 [0.991, 1.009] |
| private-supplemental | 3 | 482.895 | 481.159 | 0.996 [0.990, 1.008] | 0.996 [0.987, 1.012] |
| all | 14 | 4,296.618 | 4,291.052 | 0.999 [0.995, 1.005] | 0.998 [0.996, 1.003] |

Totals above are sums of per-case medians; they are not one pooled median.

## Group CPU, memory, and pipeline stages

| Group | Metric | Ratio of sums of case medians [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | --- | --- |
| public | cpu_ms | 0.998 [0.995, 1.007] | 1.001 [0.996, 1.008] |
| public | user_ms | 0.999 [0.995, 1.007] | 1.002 [0.999, 1.008] |
| public | system_ms | 1.003 [0.978, 1.026] | 0.992 [0.981, 1.018] |
| public | peak_rss_mib | 0.996 [0.982, 1.012] | 0.999 [0.989, 1.009] |
| public | setup_ms | 1.040 [0.984, 1.090] | 1.039 [0.984, 1.085] |
| public | compile_layout_ms | 0.999 [0.995, 1.008] | 0.999 [0.995, 1.006] |
| public | render_ms | 1.038 [0.992, 1.059] | 1.046 [0.991, 1.073] |
| public | pipeline_ms | 0.999 [0.995, 1.008] | 1.000 [0.996, 1.006] |
| private | cpu_ms | 1.001 [0.992, 1.006] | 1.000 [0.992, 1.006] |
| private | user_ms | 1.001 [0.992, 1.006] | 1.002 [0.991, 1.008] |
| private | system_ms | 0.991 [0.971, 1.012] | 0.994 [0.970, 1.018] |
| private | peak_rss_mib | 0.999 [0.987, 1.012] | 1.000 [0.990, 1.010] |
| private | setup_ms | 1.025 [0.990, 1.052] | 1.025 [0.990, 1.051] |
| private | compile_layout_ms | 1.000 [0.989, 1.006] | 0.987 [0.936, 1.012] |
| private | render_ms | 0.977 [0.911, 1.032] | 0.985 [0.891, 1.037] |
| private | pipeline_ms | 0.999 [0.989, 1.006] | 0.987 [0.978, 1.004] |
| all | cpu_ms | 0.999 [0.995, 1.005] | 1.001 [0.997, 1.005] |
| all | user_ms | 1.000 [0.996, 1.005] | 1.002 [0.999, 1.005] |
| all | system_ms | 0.999 [0.978, 1.015] | 0.993 [0.984, 1.009] |
| all | peak_rss_mib | 0.997 [0.986, 1.008] | 0.999 [0.991, 1.006] |
| all | setup_ms | 1.026 [0.992, 1.053] | 1.035 [0.990, 1.072] |
| all | compile_layout_ms | 0.999 [0.994, 1.005] | 0.996 [0.981, 1.007] |
| all | render_ms | 1.025 [0.981, 1.047] | 1.028 [0.972, 1.056] |
| all | pipeline_ms | 0.999 [0.995, 1.005] | 0.996 [0.993, 1.003] |

## Tagged wall time

| Tag | Group | Cases | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | ---: | --- | --- |
| legend | public | 2 | 0.998 [0.993, 1.005] | 0.998 [0.992, 1.005] |
| legend | all | 2 | 0.998 [0.993, 1.005] | 0.998 [0.992, 1.005] |
| markdown | public | 4 | 0.998 [0.995, 1.005] | 0.998 [0.994, 1.003] |
| markdown | all | 4 | 0.998 [0.995, 1.005] | 0.998 [0.994, 1.003] |

## Per-case measurements

| Case | Baseline wall ms | Candidate wall ms | Wall ratio [95% CI] | CPU ratio [95% CI] | RSS ratio [95% CI] |
| --- | ---: | ---: | --- | --- | --- |
| public/fulcro_rad | 103.868 | 103.652 | 0.998 [0.983, 1.005] | 0.992 [0.978, 1.002] | 1.011 [0.993, 1.021] |
| public/jupyter_aws_eks | 24.005 | 23.578 | 0.982 [0.952, 1.001] | 1.000 [0.964, 1.030] | 0.998 [0.987, 1.005] |
| public/jupyter_k8s_oidc | 28.449 | 28.608 | 1.006 [0.994, 1.046] | 1.014 [0.973, 1.051] | 1.009 [0.997, 1.016] |
| public/leios_simulator | 32.795 | 32.777 | 0.999 [0.991, 1.027] | 1.027 [1.002, 1.047] | 0.998 [0.988, 1.010] |
| public/lion_reader_frontend | 84.099 | 84.254 | 1.002 [0.993, 1.008] | 0.994 [0.981, 1.022] | 1.013 [0.991, 1.025] |
| public/mocha_soc | 184.139 | 183.853 | 0.998 [0.996, 1.015] | 1.005 [0.995, 1.014] | 1.006 [0.987, 1.028] |
| public/queue_workers | 175.518 | 175.406 | 0.999 [0.991, 1.011] | 1.004 [0.994, 1.012] | 1.006 [0.975, 1.034] |
| public/ross_overview | 93.948 | 93.959 | 1.000 [0.989, 1.014] | 1.001 [0.991, 1.017] | 0.997 [0.985, 1.013] |
| public/spyre_encoder | 69.817 | 69.354 | 0.993 [0.989, 1.008] | 0.979 [0.965, 1.011] | 0.994 [0.978, 1.009] |
| public/tpmjs_architecture | 2,040.179 | 2,036.673 | 0.998 [0.993, 1.010] | 0.997 [0.993, 1.008] | 0.959 [0.885, 1.062] |
| private-0141 | 976.905 | 977.779 | 1.001 [0.988, 1.010] | 1.002 [0.990, 1.008] | 0.997 [0.971, 1.034] |
| private-0235 | 443.122 | 441.525 | 0.996 [0.988, 1.008] | 0.999 [0.992, 1.007] | 0.999 [0.980, 1.024] |
| private-0236 | 21.266 | 21.198 | 0.997 [0.971, 1.038] | 1.008 [0.971, 1.034] | 1.000 [0.987, 1.010] |
| private-0237 | 18.507 | 18.436 | 0.996 [0.980, 1.014] | 0.991 [0.978, 1.015] | 1.002 [0.991, 1.020] |

## Allocation counters

| Group | Counter | Baseline sum of medians | Candidate sum of medians | Ratio [95% CI] |
| --- | --- | ---: | ---: | --- |
| public | alloc_bytes | 677,103,752 | 678,279,496 | 1.002 [1.000, 1.006] |
| public | alloc_objects | 6,759,789 | 6,756,834 | 1.000 [0.997, 1.001] |
| public | gc_cycles | 141 | 143 | 1.014 [0.993, 1.043] |
| private | alloc_bytes | 312,701,264 | 312,869,656 | 1.001 [0.993, 1.004] |
| private | alloc_objects | 3,243,146 | 3,243,262 | 1.000 [0.999, 1.002] |
| private | gc_cycles | 61 | 61 | 1.000 [0.984, 1.016] |
| all | alloc_bytes | 989,805,016 | 991,149,152 | 1.001 [0.998, 1.005] |
| all | alloc_objects | 10,002,935 | 10,000,096 | 1.000 [0.998, 1.001] |
| all | gc_cycles | 202 | 204 | 1.010 [1.000, 1.025] |

Full stage, CPU, RSS, allocation, range, and IQR statistics are in public-summary.json. Private rows use opaque IDs.
