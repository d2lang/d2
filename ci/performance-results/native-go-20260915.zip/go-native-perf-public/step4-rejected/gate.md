# Step 4 performance gate

Rejected after the predeclared 14-case screen (all ten public diagrams, all three supplemental routing records and the profiled case `private-0141`). Ten paired rounds after two warmups and three separate allocation rounds produced 420 exact-output rows. Full preflight passed 246 SVG pairs and one matching existing error; E2E/TALA and lifecycle/accounting tests passed.

Pipeline change was −0.099% [−0.531%, +0.487%]; CPU −0.076% [−0.459%, +0.496%]; allocated bytes +0.136% [−0.204%, +0.512%]. Public allocated bytes increased +0.174% [+0.040%, +0.560%]. This does not establish a runtime win. The candidate is removed; the screen and source are retained, without additional selected reruns.

The timing evidence is limited to this 14-case screen; no full-corpus Step 4 timing campaign was run. The rejected source patch and test are retained under `source/` and are not part of the accepted production change.
