# Dated native Go evidence bundle

Read `REPORT-2026-09-15.md` first. This frozen evidence package supports one optimization PR. It includes three retained changes, a rejected routing experiment, and a direct original-baseline-versus-final comparison. The expanded directory must stay outside a Go module; only the dated report and compact ZIP belong in `ci/performance-results/`.

## Reproduce the direct comparison on ten public cases

No Rust checkout or private data is required. Inputs are existing files under `e2etests/testdata/files/` in the Go repository. `public-workloads.json` records their verified hashes, public names and exact render configurations.

Create clean Go worktrees at these measured revisions:

- Original baseline: `bf33790338b9854cb2a34418e69c17f9abf8de4b`.
- Final accepted source: `cccf1c79f309f4220e5bd49dcfdcffea61857a9e`.

Build **the same absolute `frozen/runner-v2.go` path** in both checkouts, using Go 1.27 and identical flags. Each command runs from its corresponding Go module checkout:

```
CGO_ENABLED=0 GOTOOLCHAIN=local go build -trimpath -o /absolute/output/baseline /absolute/evidence/frozen/runner-v2.go
CGO_ENABLED=0 GOTOOLCHAIN=local go build -trimpath -o /absolute/output/final /absolute/evidence/frozen/runner-v2.go
```

Pause other builds, tests and CPU-heavy work, then use a fresh output directory:

```
python3 reproduce-public.py --baseline /absolute/output/baseline --candidate /absolute/output/final --source /absolute/go-checkout --out /absolute/new-result-directory --comparison cumulative
python3 frozen/summarize.py /absolute/new-result-directory --resamples 2000 --seed 20260914
```

The script runs exact-output preflight, ten paired timing rounds after two warmups, then three separate allocation rounds. It retains authentic input/config/binary/SVG hashes in the new local evidence and stops on output disagreement. It requires POSIX `wait4` and checks macOS/Linux RSS units. Use a new output directory for every campaign.

The optional `--comparison incremental|cumulative` argument labels the chosen source comparison in metadata; it defaults to `incremental` and does not change the protocol. `cumulative` is appropriate only for a direct original-baseline-versus-final run. It does not combine earlier results or manufacture a cumulative interval from them.

Both binaries must use v2 for the direct comparison. Its compatibility adapter explicitly supplies the compiler ruler when the source API supports it, matching the final native SVG CLI. The adapter runs inside the render/pipeline/allocation measurement. Production CLI code uses direct assignment. Never compare a v1-built baseline with a v2-built candidate.

New measurements have a different scheduling/noise history and will not reproduce the original numerical estimates exactly. Only recalculating the distributed original rows should match exactly. This public reproduction covers ten cases; private workloads cannot be rerun from the package.

## Recalculate the distributed numbers

Requires Python 3. The reader imports the exact frozen estimator and replaces only its private-input validator with explicit numeric/pair validation. It never fabricates input, config or SVG hashes. It checks all metrics, distributions, aggregate estimates and confidence intervals against the retained reports:

```
python3 recalculate.py step1/step1-full
python3 recalculate.py step1/step1-markdown-confirm
python3 recalculate.py step1/step1-controls-confirm
python3 recalculate.py step2/step2-full
python3 recalculate.py step2/step2-targets-confirm
python3 recalculate.py step2/step2-controls-confirm
python3 recalculate.py step3/step3-full
python3 recalculate.py step3/step3-controls-confirm
python3 recalculate.py step4-rejected/step4-screen
python3 recalculate.py overall/overall-final
python3 recalculate.py overall/overall-controls-confirm
```

The direct full-corpus campaign remains the cumulative estimate. Its predeclared seven-case confirmation is retained separately and is never pooled or substituted. The 100-row public controller smoke is validation only and is excluded from the 33,640 measured-evidence rows across eleven campaigns.

`summary.json` and `summary.md` preserve the original local validator's claims. Numeric recalculation verifies statistics and pair structure only; private input/output identity claims remain local evidence. Original numeric values and row numbers are preserved, while descriptive private IDs become stable opaque IDs. Metadata retains only coarse Markdown/legend membership needed to reconstruct those cohorts.

`provenance.json` records source revisions, toolchain and authentic frozen script/binary evidence. `SHA256SUMS.json` verifies distributed file integrity only; it does not replace omitted private identity checks. Private source text, descriptive identifiers, user/private paths, errors, proprietary font bytes and SVGs are absent. Exact runners mention optional font product filenames but contain no font data.

## Reproduce individual retained steps

The retained incremental campaigns use these pairs. Full source hashes are in `provenance.json` and the report:

| Step | Baseline source | Candidate source | Same runner for both |
| --- | --- | --- | --- |
| 1 | Original `bf337903` | Step 1 `d6a52f13` | `frozen/runner-v1.go` |
| 2 | Step 1 `d6a52f13` | Step 2 `bb3efe82` | `frozen/runner-v2.go` |
| 3 | Step 2 `bb3efe82` | Step 3 `cccf1c79` | `frozen/runner-v2.go` |

Build the indicated runner from each corresponding clean source checkout with the same Go version and flags shown above. Run `reproduce-public.py` with `--comparison incremental` and a fresh output directory, followed by the frozen summarizer. Step 1's original v1 rows do not record ruler adoption. In the Step 2 campaigns only the candidate adopts it; both sides do in Step 3.

The rejected Step 4 source and focused test are preserved under `step4-rejected/source/`. Its 14-case screen did not establish a runtime win; no full-corpus Step 4 timing campaign was run. The patch is historical experiment evidence and is not applied to the final accepted source.

The reader and reproduction script are dated review utilities. Changes to future runtime behavior require a new frozen runner and explicit protocol metadata. Keep expanded runner Go files and the rejected test outside the checkout: duplicate runner main packages must not be discovered by `go test ./...`. Repository integration consists only of `native-go-20260915.md` and `native-go-20260915.zip`.
