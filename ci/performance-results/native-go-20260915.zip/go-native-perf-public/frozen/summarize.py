#!/usr/bin/env python3
"""Validate and summarize paired Go A/B runs without reading workload contents.

Usage: python3 summarize.py RUN [--resamples 2000] [--seed 20260914]
       python3 summarize.py --self-test

Required metadata: baseline/candidate labels, binary_hashes keyed by those
labels, cases containing id/public_id/private/group/tags/input_sha256, and
comparison ('incremental' or 'cumulative'). rounds defaults to 10.
allocation_rounds (or its alloc_rounds alias) is optional; an allocation phase,
if present, must have at least three rounds. Conflicting aliases are rejected.
Each sample must carry binary/input/config/SVG/oracle SHA-256 identities plus
returncode=0, timed_out=false, and svg_exact=true. Expected oracle/config hashes
in case metadata (or global config_sha256) are checked when provided. Otherwise
their consistency across every variant, round, and phase is still required.
The CLI requires measured-started.json/measured-complete.json and, when
allocation rounds are requested, alloc-started.json/alloc-complete.json. Their
case counts, round counts, pair counts, and unchanged-identity confirmations
must match metadata. Generic summarize() remains usable with synthetic rows.

Both members of a pair are always resampled together. All cases share the same
round-block draw, including for aggregate intervals. The two-sided percentile
interval describes measurement uncertainty for these fixed cases, not an
inference about unseen workloads. Allocation measurements are kept separate.
No result is a keep/drop decision; callers must assess effect size and scope.

Outputs: summary.json (local IDs), public-summary.json and public-summary.md
(private case IDs replaced with opaque public_id; no raw metadata or samples).
Only markdown/legend tags are exposed in public aggregate reports. No workload
content, paths, errors, font names, or private display names are exported.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import statistics
import sys
import tempfile
from typing import Any


TIMING_METRICS = (
    'wall_ms', 'cpu_ms', 'user_ms', 'system_ms', 'peak_rss_mib',
    'setup_ms', 'compile_layout_ms', 'render_ms', 'pipeline_ms',
)
ALLOCATION_METRICS = ('alloc_bytes', 'alloc_objects', 'gc_cycles')
PUBLIC_TAGS = frozenset(('markdown', 'legend'))
OUTPUT_NAMES = ('summary.json', 'public-summary.json', 'public-summary.md')
SHA256 = re.compile(r'[0-9a-fA-F]{64}\Z')
PRIVATE_ID = re.compile(r'private-[0-9]{4,}\Z')


class ValidationError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def sha(value: Any, context: str) -> str:
    require(isinstance(value, str) and SHA256.fullmatch(value) is not None,
            f'{context}: missing or malformed SHA-256')
    return value.lower()


def finite_number(value: Any, context: str) -> float:
    require(isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value >= 0,
            f'{context}: expected a finite nonnegative number')
    return float(value)


def integer(value: Any, context: str, minimum: int = 0) -> int:
    require(isinstance(value, int) and not isinstance(value, bool)
            and value >= minimum, f'{context}: expected integer >= {minimum}')
    return value


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    pos = (len(ordered) - 1) * fraction
    low = math.floor(pos)
    high = math.ceil(pos)
    return ordered[low] + (ordered[high] - ordered[low]) * (pos - low)


def distribution(values: list[float]) -> dict[str, Any]:
    q1, q3 = percentile(values, .25), percentile(values, .75)
    return {'median': statistics.median(values), 'min': min(values),
            'max': max(values), 'q1': q1, 'q3': q3, 'iqr': q3 - q1,
            'n': len(values)}


def ratio(candidate: float, baseline: float) -> float | None:
    return candidate / baseline if baseline > 0 else None


def comparison(point: float | None, draws: list[float | None]) -> dict[str, Any]:
    valid = [value for value in draws if value is not None]
    # Discarding zero-denominator draws would bias the interval. Leave it
    # undefined unless every draw has a defined ratio.
    ci = ([percentile(valid, .025), percentile(valid, .975)]
          if len(valid) == len(draws) and valid else None)
    excludes = ci[1] < 1 or ci[0] > 1 if ci is not None else None
    direction = ('lower' if ci[1] < 1 else 'higher' if ci[0] > 1
                 else 'inconclusive') if ci is not None else 'undefined'
    result = {'ratio_candidate_over_baseline': point,
              'percent_change': (point - 1) * 100 if point is not None else None,
              'ci95': ci, 'ci_excludes_one': excludes,
              'ci_direction': direction, 'bootstrap_resamples': len(draws),
              'defined_bootstrap_resamples': len(valid)}
    if point is None or ci is None:
        result['undefined_reason'] = 'zero baseline or nonpositive geometric-mean operand'
    return result


def field(row: dict[str, Any], name: str) -> Any:
    return row.get(name) if name in row else row.get('stages', {}).get(name)


def validate(metadata: dict[str, Any], rows: list[dict[str, Any]]) -> dict[str, Any]:
    require(isinstance(metadata, dict), 'metadata must be an object')
    labels = [metadata.get('baseline'), metadata.get('candidate')]
    require(all(isinstance(label, str) and label for label in labels)
            and labels[0] != labels[1], 'distinct baseline/candidate labels required')
    require(metadata.get('comparison') in ('incremental', 'cumulative'),
            'comparison must be incremental or cumulative')
    allocation_counts = {
        name: integer(metadata[name], name)
        for name in ('allocation_rounds', 'alloc_rounds') if name in metadata
    }
    require(len(set(allocation_counts.values())) <= 1,
            'conflicting allocation_rounds and alloc_rounds aliases')
    allocation_rounds = next(iter(allocation_counts.values()), None)
    require(allocation_rounds is None or allocation_rounds == 0 or allocation_rounds >= 3,
            'allocation_rounds must be zero or at least 3')
    binary_hashes = metadata.get('binary_hashes', {})
    require(isinstance(binary_hashes, dict), 'binary_hashes must be an object')
    binaries = {label: sha(binary_hashes.get(label), f'binary {label}') for label in labels}
    cases = metadata.get('cases')
    require(isinstance(cases, list) and cases, 'nonempty cases list required')
    by_id: dict[str, dict[str, Any]] = {}
    public_ids: set[str] = set()
    expected: dict[str, dict[str, str | None]] = {}
    for case in cases:
        require(isinstance(case, dict), 'case must be an object')
        cid, public_id = case.get('id'), case.get('public_id')
        require(isinstance(cid, str) and cid and cid not in by_id, 'case IDs must be unique strings')
        require(isinstance(public_id, str) and public_id and public_id not in public_ids,
                f'{cid}: public_id must be a unique nonempty string')
        private = case.get('private')
        require(type(private) is bool, f'{cid}: private must be boolean')
        require(case.get('group') in ('public', 'private', 'private-supplemental'),
                f'{cid}: unknown group')
        require(private == (case['group'] != 'public'), f'{cid}: group/private disagree')
        require(not private or PRIVATE_ID.fullmatch(public_id) is not None,
                f'{cid}: private public_id must be opaque, e.g. private-0001')
        tags = case.get('tags', [])
        require(isinstance(tags, list) and all(isinstance(tag, str) and tag for tag in tags)
                and len(set(tags)) == len(tags), f'{cid}: tags must be distinct strings')
        expected[cid] = {'input_sha256': sha(case.get('input_sha256'), f'{cid} input')}
        for name in ('oracle_sha256', 'config_sha256'):
            value = case.get(name, metadata.get(name))
            expected[cid][name] = sha(value, f'{cid} {name}') if value is not None else None
        by_id[cid] = case
        public_ids.add(public_id)
    rounds = integer(metadata.get('rounds', 10), 'rounds', 2)
    phases: dict[str, dict[tuple[str, int, str], dict[str, Any]]] = {}
    ignored_preflight = 0
    for line, row in enumerate(rows, 1):
        require(isinstance(row, dict), f'row {line}: sample must be an object')
        phase = row.get('phase')
        if phase == 'preflight':
            ignored_preflight += 1
            continue
        require(phase in ('measured', 'warmup', 'alloc'), f'row {line}: unknown phase')
        cid, label = row.get('case'), row.get('variant')
        require(cid in by_id, f'row {line}: unknown case')
        require(label in labels, f'row {line}: unknown variant')
        raw_round = row.get('round')
        require(type(raw_round) is int, f'row {line}: round must be an integer')
        round_id = (raw_round if phase == 'warmup'
                    else integer(raw_round, f'row {line} round'))
        context = f'{cid}/{label}/{phase}/{round_id}'
        require(type(row.get('returncode')) is int and row['returncode'] == 0,
                f'{context}: failed or missing returncode')
        require(row.get('timed_out') is False, f'{context}: timeout or missing timeout status')
        require(row.get('svg_exact') is True, f'{context}: SVG was not verified exact')
        require(not row.get('error'), f'{context}: sample carries an error')
        require(sha(row.get('binary_sha256'), context + ' binary') == binaries[label],
                f'{context}: binary identity mismatch')
        for name in ('input_sha256', 'oracle_sha256', 'config_sha256'):
            actual = sha(row.get(name), context + ' ' + name)
            if expected[cid][name] is None:
                expected[cid][name] = actual
            require(actual == expected[cid][name], f'{context}: {name} identity mismatch')
        require(sha(row.get('svg_sha256'), context + ' SVG') == expected[cid]['oracle_sha256'],
                f'{context}: SVG/oracle identity mismatch')
        require(isinstance(row.get('stages', {}), dict), f'{context}: stages must be an object')
        metrics = ALLOCATION_METRICS if phase == 'alloc' else TIMING_METRICS
        if phase != 'warmup':
            for name in metrics:
                finite_number(field(row, name), f'{context} {name}')
        key = (cid, round_id, label)
        phase_rows = phases.setdefault(phase, {})
        require(key not in phase_rows, f'{context}: duplicate sample')
        phase_rows[key] = row
    require('measured' in phases, 'no measured samples')
    phase_rounds: dict[str, list[int]] = {}
    for phase, phase_rows in phases.items():
        round_ids = sorted({key[1] for key in phase_rows})
        count = len(round_ids)
        starts_correctly = (round_ids[0] in (0, 1)
                            or (phase == 'warmup' and round_ids == list(range(-count, 0))))
        require(round_ids == list(range(round_ids[0], round_ids[0] + count))
                and starts_correctly,
                f'{phase}: rounds must be contiguous, starting at 0/1 or negative warmup rounds ending at -1')
        if phase == 'measured':
            require(count == rounds, f'measured: expected {rounds} rounds, got {count}')
        elif phase == 'alloc':
            require(count >= 3, 'allocation phase requires at least 3 paired rounds')
            if allocation_rounds is not None:
                require(count == allocation_rounds,
                        'allocation round count differs from metadata')
        elif metadata.get('warmup_rounds', metadata.get('warmups')) is not None:
            require(count == integer(metadata.get('warmup_rounds', metadata.get('warmups')), 'warmup_rounds'),
                    'warmup round count differs from metadata')
        for cid in by_id:
            for round_id in round_ids:
                for label in labels:
                    require((cid, round_id, label) in phase_rows,
                            f'{cid}/{phase}/{round_id}: missing {label} pair member')
        phase_rounds[phase] = round_ids
    require(not allocation_rounds or 'alloc' in phases,
            'metadata requests allocation rounds but no allocation samples exist')
    require(not metadata.get('warmup_rounds', metadata.get('warmups')) or 'warmup' in phases,
            'metadata requests warmup rounds but no warmup samples exist')
    return {'labels': labels, 'cases': cases, 'phases': phases,
            'phase_rounds': phase_rounds, 'ignored_preflight_rows': ignored_preflight,
            'identities': expected}


def validate_completion_markers(run: Path, metadata: dict[str, Any]) -> dict[str, str]:
    """CLI gate: a complete row set alone is not proof the harness finished."""
    expected_cases = [case['id'] for case in metadata['cases']]
    require(len(set(expected_cases)) == len(expected_cases), 'metadata has duplicate case IDs')
    measured_rounds = integer(metadata.get('rounds', 10), 'rounds', 2)
    allocation_counts = {
        name: integer(metadata[name], name)
        for name in ('allocation_rounds', 'alloc_rounds') if name in metadata
    }
    require(len(set(allocation_counts.values())) <= 1,
            'conflicting allocation_rounds and alloc_rounds aliases')
    alloc_rounds = next(iter(allocation_counts.values()), 0)
    require(alloc_rounds == 0 or alloc_rounds >= 3,
            'allocation_rounds must be zero or at least 3')
    phases = [('measured', measured_rounds,
               integer(metadata.get('warmup_rounds', metadata.get('warmups', 0)), 'warmups'))]
    if alloc_rounds:
        phases.append(('alloc', alloc_rounds, 0))
    marker_hashes = {}
    for phase, rounds, warmups in phases:
        records = {}
        for status in ('started', 'complete'):
            filename = f'{phase}-{status}.json'
            path = run / filename
            require(path.is_file(), f'missing required completion evidence: {filename}')
            contents = path.read_bytes()
            marker_hashes[filename] = hashlib.sha256(contents).hexdigest()
            records[status] = json.loads(contents)
            require(isinstance(records[status], dict), f'{filename}: marker must be an object')
        started, complete = records['started'], records['complete']
        actual_cases = started.get('cases')
        require(isinstance(actual_cases, list)
                and all(isinstance(cid, str) for cid in actual_cases)
                and len(actual_cases) == len(expected_cases)
                and set(actual_cases) == set(expected_cases),
                f'{phase}-started.json: case IDs do not exactly match metadata')
        require(integer(started.get('rounds'), f'{phase} started rounds') == rounds,
                f'{phase}-started.json: round count differs from metadata')
        require(integer(started.get('warmups'), f'{phase} started warmups') == warmups,
                f'{phase}-started.json: warmup count differs from metadata')
        require(complete.get('input_identities_unchanged') is True,
                f'{phase}-complete.json: input identities were not verified unchanged')
        require(complete.get('binary_identities_unchanged') is True,
                f'{phase}-complete.json: binary identities were not verified unchanged')
        require(integer(complete.get('pairs'), f'{phase} completed pairs') == len(expected_cases) * rounds,
                f'{phase}-complete.json: completed pair count differs from metadata')
    return marker_hashes


def summarize(metadata: dict[str, Any], rows: list[dict[str, Any]],
              resamples: int = 2000, seed: int = 20260914) -> dict[str, Any]:
    integer(resamples, 'resamples', 100)
    data = validate(metadata, rows)
    cases, labels = data['cases'], data['labels']
    # One fixed block draw per phase and bootstrap replicate, shared by every
    # case and metric. Never resample cases: the observed corpus is fixed.
    rng = random.Random(seed)
    blocks: dict[str, list[list[int]]] = {}
    for phase in ('measured', 'alloc'):
        if phase in data['phases']:
            n = len(data['phase_rounds'][phase])
            blocks[phase] = [[rng.randrange(n) for _ in range(n)] for _ in range(resamples)]
    result: dict[str, Any] = {
        'schema_version': 1, 'comparison': metadata['comparison'],
        'baseline': labels[0], 'candidate': labels[1],
        'method': {
            'estimator': 'ratio of candidate median to baseline median',
            'confidence_interval': 'two-sided 95% paired percentile bootstrap',
            'resamples': resamples, 'seed': seed,
            'resampling_unit': 'whole paired round block shared across all cases',
            'aggregate_estimators': ['ratio of sums of case medians',
                                     'equal-case geometric mean of case median ratios'],
            'scope': 'fixed observed cases; intervals do not model unseen workloads',
            'multiple_comparisons': 'intervals are unadjusted; no automatic keep/drop gate',
            'allocation': 'separate alloc phase; excluded from measured timing estimates',
            'memory': 'peak RSS is process memory; allocation counters are separate',
            'warmup': 'validated, excluded from all estimates',
        },
        'validation': {'status': 'passed', 'case_count': len(cases),
                       'phase_rounds': {phase: len(rounds) for phase, rounds in data['phase_rounds'].items()},
                       'ignored_preflight_rows': data['ignored_preflight_rows'],
                       'all_pairs_complete': True, 'all_svg_exact': True,
                       'all_sample_identities_consistent': True},
        'cases': [], 'groups': {}, 'tags': {},
    }
    # Bootstrap medians are retained only internally, not emitted in reports.
    cache: dict[tuple[str, str], dict[str, dict[str, Any]]] = {}
    for case in cases:
        item = {key: case.get(key, [] if key == 'tags' else None)
                for key in ('id', 'public_id', 'private', 'group', 'tags')}
        for phase, metric_names, output_key in (
                ('measured', TIMING_METRICS, 'metrics'),
                ('alloc', ALLOCATION_METRICS, 'allocation_metrics')):
            if phase not in blocks:
                continue
            metrics = {}
            round_ids = data['phase_rounds'][phase]
            phase_rows = data['phases'][phase]
            for name in metric_names:
                values = [[float(field(phase_rows[(case['id'], r, label)], name))
                           for r in round_ids] for label in labels]
                base_stats, cand_stats = map(distribution, values)
                base_draws = [statistics.median([values[0][i] for i in indices])
                              for indices in blocks[phase]]
                cand_draws = [statistics.median([values[1][i] for i in indices])
                              for indices in blocks[phase]]
                point = ratio(cand_stats['median'], base_stats['median'])
                draws = [ratio(c, b) for b, c in zip(base_draws, cand_draws)]
                metrics[name] = {'baseline': base_stats, 'candidate': cand_stats,
                                 **comparison(point, draws)}
                cache.setdefault((phase, name), {})[case['id']] = {
                    'baseline': base_stats['median'], 'candidate': cand_stats['median'],
                    'baseline_draws': base_draws, 'candidate_draws': cand_draws,
                }
            item[output_key] = metrics
        result['cases'].append(item)
    selectors = {
        'all': [case['id'] for case in cases],
        'public': [case['id'] for case in cases if not case['private']],
        'private': [case['id'] for case in cases if case['private']],
        'private-supplemental': [case['id'] for case in cases if case['group'] == 'private-supplemental'],
    }
    for group, ids in selectors.items():
        result['groups'][group] = aggregate(ids, cache, resamples)
    for tag in sorted({tag for case in cases for tag in case.get('tags', [])}):
        selected = [case for case in cases if tag in case.get('tags', [])]
        # Report each tag's public/private split too; a tag may otherwise pool
        # a few expensive public examples with many tiny private examples.
        result['tags'][tag] = {
            'all': aggregate([case['id'] for case in selected], cache, resamples),
            'public': aggregate([case['id'] for case in selected if not case['private']], cache, resamples),
            'private': aggregate([case['id'] for case in selected if case['private']], cache, resamples),
        }
    return result


def geometric_ratio(baselines: list[float], candidates: list[float]) -> float | None:
    if any(value <= 0 for value in baselines + candidates):
        return None
    return math.exp(statistics.fmean(math.log(c) - math.log(b)
                                    for b, c in zip(baselines, candidates)))


def aggregate(ids: list[str], cache: dict[tuple[str, str], dict[str, dict[str, Any]]],
              resamples: int) -> dict[str, Any]:
    result: dict[str, Any] = {'case_count': len(ids)}
    if not ids:
        return result
    for (phase, name), by_case in cache.items():
        entries = [by_case[cid] for cid in ids]
        baseline = [entry['baseline'] for entry in entries]
        candidate = [entry['candidate'] for entry in entries]
        sum_draws: list[float | None] = []
        geo_draws: list[float | None] = []
        for draw in range(resamples):
            b = [entry['baseline_draws'][draw] for entry in entries]
            c = [entry['candidate_draws'][draw] for entry in entries]
            sum_draws.append(ratio(math.fsum(c), math.fsum(b)))
            geo_draws.append(geometric_ratio(b, c))
        bsum, csum = math.fsum(baseline), math.fsum(candidate)
        output_key = 'metrics' if phase == 'measured' else 'allocation_metrics'
        result.setdefault(output_key, {})[name] = {
            'sum_case_medians': {'baseline': bsum, 'candidate': csum,
                                 **comparison(ratio(csum, bsum), sum_draws)},
            'equal_case_geometric_mean': {
                **comparison(geometric_ratio(baseline, candidate), geo_draws)},
        }
    return result


def public_summary(local: dict[str, Any]) -> dict[str, Any]:
    # Build an allowlisted report, never recursively redact raw metadata. Even
    # unforeseen sample fields therefore cannot leak into a public artifact.
    result = {key: copy.deepcopy(local[key])
              for key in ('schema_version', 'comparison', 'method', 'validation', 'groups')}
    result.update({'baseline': 'baseline', 'candidate': 'candidate'})
    result['tags'] = {key: copy.deepcopy(value) for key, value in local['tags'].items()
                      if key in PUBLIC_TAGS}
    result['cases'] = []
    for case in local['cases']:
        item = {'id': case['public_id'], 'private': case['private'],
                'metrics': copy.deepcopy(case['metrics'])}
        if 'allocation_metrics' in case:
            item['allocation_metrics'] = copy.deepcopy(case['allocation_metrics'])
        if not case['private']:
            item['group'] = 'public'
            item['tags'] = [tag for tag in case['tags'] if tag in PUBLIC_TAGS]
        result['cases'].append(item)
    return result


def fmt_number(value: float | None, digits: int = 3) -> str:
    return 'undefined' if value is None else f'{value:,.{digits}f}'


def fmt_ratio(value: dict[str, Any]) -> str:
    point, ci = value['ratio_candidate_over_baseline'], value['ci95']
    if point is None:
        return 'undefined'
    return f'{point:.3f} [{ci[0]:.3f}, {ci[1]:.3f}]' if ci else f'{point:.3f} [undefined]'


def escape_md(value: str) -> str:
    return value.replace('\\', '\\\\').replace('|', '\\|').replace('\n', ' ').replace('\r', ' ')


def markdown(report: dict[str, Any]) -> str:
    method = report['method']
    phases = report['validation']['phase_rounds']
    lines = [
        '# Go A/B measurements', '',
        f"Comparison: {report['comparison']}. {report['validation']['case_count']} cases; "
        f"{phases['measured']} measured paired rounds; {phases.get('alloc', 0)} allocation paired rounds.", '',
        'All samples passed exit, timeout, paired-round, identity, and exact SVG checks. '
        'Only preflight-success cases in this selected run are represented; consult the local '
        'preflight report for excluded or failed cases.', '',
        'Ratios are candidate / baseline; lower values indicate lower resource use. Brackets '
        f"show 95% paired percentile bootstrap intervals ({method['resamples']:,} resamples; "
        f"seed {method['seed']}). Whole round blocks are shared across cases. Intervals are "
        'unadjusted for multiple comparisons and describe these fixed cases. An interval '
        'containing 1 is inconclusive. These results make no automatic keep/drop decision.', '',
        'Allocation counters come from separate instrumented runs. Peak RSS is process '
        'memory. Public and private groups are reported separately; the all-cases result '
        'is descriptive and does not substitute for either group.', '',
        '## Group wall time', '',
        '| Group | Cases | Baseline total ms | Candidate total ms | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |',
        '| --- | ---: | ---: | ---: | --- | --- |',
    ]
    for name in ('public', 'private', 'private-supplemental', 'all'):
        group = report['groups'][name]
        if not group['case_count']:
            continue
        metrics = group['metrics']['wall_ms']
        total = metrics['sum_case_medians']
        lines.append(f"| {name} | {group['case_count']} | {fmt_number(total['baseline'])} | "
                     f"{fmt_number(total['candidate'])} | {fmt_ratio(total)} | "
                     f"{fmt_ratio(metrics['equal_case_geometric_mean'])} |")
    lines.extend(['', 'Totals above are sums of per-case medians; they are not one pooled median.', '',
                  '## Group CPU, memory, and pipeline stages', '',
                  '| Group | Metric | Ratio of sums of case medians [95% CI] | Equal-case geometric ratio [95% CI] |',
                  '| --- | --- | --- | --- |'])
    for name in ('public', 'private', 'all'):
        group = report['groups'][name]
        for metric, stats in group.get('metrics', {}).items():
            if metric == 'wall_ms':
                continue
            lines.append(f"| {name} | {metric} | {fmt_ratio(stats['sum_case_medians'])} | "
                         f"{fmt_ratio(stats['equal_case_geometric_mean'])} |")
    if report['tags']:
        lines.extend(['', '## Tagged wall time', '',
                      '| Tag | Group | Cases | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |',
                      '| --- | --- | ---: | --- | --- |'])
        for tag, groups in report['tags'].items():
            for name in ('public', 'private', 'all'):
                group = groups[name]
                if not group['case_count']:
                    continue
                metric = group['metrics']['wall_ms']
                lines.append(f"| {tag} | {name} | {group['case_count']} | "
                             f"{fmt_ratio(metric['sum_case_medians'])} | "
                             f"{fmt_ratio(metric['equal_case_geometric_mean'])} |")
    lines.extend(['', '## Per-case measurements', '',
                  '| Case | Baseline wall ms | Candidate wall ms | Wall ratio [95% CI] | CPU ratio [95% CI] | RSS ratio [95% CI] |',
                  '| --- | ---: | ---: | --- | --- | --- |'])
    for case in report['cases']:
        wall = case['metrics']['wall_ms']
        lines.append(f"| {escape_md(case['id'])} | {fmt_number(wall['baseline']['median'])} | "
                     f"{fmt_number(wall['candidate']['median'])} | {fmt_ratio(wall)} | "
                     f"{fmt_ratio(case['metrics']['cpu_ms'])} | "
                     f"{fmt_ratio(case['metrics']['peak_rss_mib'])} |")
    if phases.get('alloc'):
        lines.extend(['', '## Allocation counters', '',
                      '| Group | Counter | Baseline sum of medians | Candidate sum of medians | Ratio [95% CI] |',
                      '| --- | --- | ---: | ---: | --- |'])
        for name in ('public', 'private', 'all'):
            for metric, stats in report['groups'][name].get('allocation_metrics', {}).items():
                total = stats['sum_case_medians']
                lines.append(f"| {name} | {metric} | {fmt_number(total['baseline'], 0)} | "
                             f"{fmt_number(total['candidate'], 0)} | {fmt_ratio(total)} |")
    lines.extend(['', 'Full stage, CPU, RSS, allocation, range, and IQR statistics are in '
                  'public-summary.json. Private rows use opaque IDs.', ''])
    return '\n'.join(lines)


def atomic_write(path: Path, text: str) -> None:
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                     prefix='.' + path.name + '.', delete=False) as out:
        temp = Path(out.name)
        out.write(text)
    try:
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def self_test() -> None:
    """Tiny synthetic checks only: no native binaries or actual workloads."""
    h = lambda digit: digit * 64
    metadata = {
        'baseline': 'before', 'candidate': 'after', 'comparison': 'incremental', 'rounds': 4,
        'binary_hashes': {'before': h('a'), 'after': h('b')},
        'cases': [
            {'id': 'public/example', 'public_id': 'public/example', 'private': False,
             'group': 'public', 'tags': ['markdown'], 'input_sha256': h('1'),
             'oracle_sha256': h('2'), 'config_sha256': h('3')},
            {'id': 'SECRET_INPUT_AND_FONT_NAME', 'public_id': 'private-0001', 'private': True,
             'group': 'private', 'tags': ['legend', 'SECRET_TAG'], 'input_sha256': h('4'),
             'oracle_sha256': h('5'), 'config_sha256': h('6')},
        ],
    }
    rows = []
    for case_index, case in enumerate(metadata['cases']):
        for phase, rounds in (('measured', 4), ('alloc', 3)):
            for r in range(rounds):
                for label, factor in (('before', 1), ('after', .5)):
                    value = (case_index + 1) * (r + 1) * factor
                    row = {'case': case['id'], 'variant': label, 'phase': phase, 'round': r,
                           'returncode': 0, 'timed_out': False, 'svg_exact': True,
                           'binary_sha256': metadata['binary_hashes'][label],
                           'input_sha256': case['input_sha256'], 'config_sha256': case['config_sha256'],
                           'svg_sha256': case['oracle_sha256'], 'oracle_sha256': case['oracle_sha256'],
                           'stages': {}, 'secret_path': '/SECRET_PATH', 'error': ''}
                    for metric in TIMING_METRICS[:5]:
                        row[metric] = value
                    for metric in TIMING_METRICS[5:] + ALLOCATION_METRICS:
                        row['stages'][metric] = value
                    rows.append(row)
    result = summarize(metadata, rows, 100, 7)
    assert result == summarize(metadata, rows, 100, 7), 'bootstrap must be deterministic'
    metric = result['cases'][0]['metrics']['wall_ms']
    assert metric['ci95'] == [.5, .5] and metric['ci_excludes_one'] is True
    assert result['groups']['all']['metrics']['wall_ms']['sum_case_medians']['ci95'] == [.5, .5]
    public = public_summary(result)
    rendered = json.dumps(public) + markdown(public)
    assert 'SECRET' not in rendered, 'public report leaked private data'
    assert 'private-0001' in rendered
    for label, mutate in (
        ('missing pair', lambda r: r.pop(0)),
        ('duplicate pair', lambda r: r.append(copy.deepcopy(r[0]))),
        ('wrong binary', lambda r: r[0].update(binary_sha256=h('f'))),
        ('wrong input', lambda r: r[0].update(input_sha256=h('f'))),
        ('wrong config', lambda r: r[0].update(config_sha256=h('f'))),
        ('wrong oracle', lambda r: r[0].update(oracle_sha256=h('f'), svg_sha256=h('f'))),
        ('wrong SVG', lambda r: r[0].update(svg_sha256=h('f'))),
        ('failed exit', lambda r: r[0].update(returncode=1)),
        ('timeout', lambda r: r[0].update(timed_out=True)),
        ('missing metric', lambda r: r[0].pop('wall_ms')),
    ):
        bad = copy.deepcopy(rows)
        mutate(bad)
        try:
            validate(metadata, bad)
        except ValidationError:
            pass
        else:
            raise AssertionError(f'accepted {label}')
    no_alloc = [row for row in rows if row['phase'] != 'alloc']
    assert 'allocation_metrics' not in summarize(metadata, no_alloc, 100, 7)['cases'][0]
    zeros = copy.deepcopy(rows)
    for row in zeros:
        row['stages']['gc_cycles'] = 0
    assert summarize(metadata, zeros, 100, 7)['cases'][0]['allocation_metrics']['gc_cycles']['ci95'] is None
    # A shared round drift reverses effects in the two cases. A shared block
    # draw must preserve the aggregate cancellation exactly at every draw.
    anticorrelated = copy.deepcopy(no_alloc)
    for row in anticorrelated:
        value = 1 if row['round'] < 2 else 3
        if (row['case'] == metadata['cases'][1]['id']) != (row['variant'] == 'after'):
            value = 4 - value
        row['wall_ms'] = value
    blocked = summarize(metadata, anticorrelated, 100, 9)
    assert blocked['groups']['all']['metrics']['wall_ms']['sum_case_medians']['ci95'] == [1., 1.]
    # The CLI must require explicit successful completion of both requested
    # phases; generic summarize() above deliberately remains artifact-agnostic.
    with tempfile.TemporaryDirectory() as tmp:
        run = Path(tmp)
        marker_metadata = {**metadata, 'allocation_rounds': 3, 'warmups': 2}
        try:
            validate_completion_markers(run, marker_metadata)
        except ValidationError:
            pass
        else:
            raise AssertionError('accepted absent completion markers')
        for phase, rounds, warmups in (('measured', 4, 2), ('alloc', 3, 0)):
            (run / f'{phase}-started.json').write_text(json.dumps({
                'cases': [case['id'] for case in metadata['cases']],
                'rounds': rounds, 'warmups': warmups,
            }))
            (run / f'{phase}-complete.json').write_text(json.dumps({
                'input_identities_unchanged': True, 'binary_identities_unchanged': True,
                'pairs': 2 * rounds,
            }))
        assert len(validate_completion_markers(run, marker_metadata)) == 4
        for key, value in (('input_identities_unchanged', False), ('binary_identities_unchanged', False),
                           ('pairs', 7)):
            path = run / 'measured-complete.json'
            original = path.read_text()
            record = json.loads(original)
            record[key] = value
            path.write_text(json.dumps(record))
            try:
                validate_completion_markers(run, marker_metadata)
            except ValidationError:
                pass
            else:
                raise AssertionError(f'accepted incorrect completion marker {key}')
            path.write_text(original)
        for changed in ({'cases': ['different', 'cases']}, {'rounds': 3}, {'warmups': 1}):
            path = run / 'measured-started.json'
            original = path.read_text()
            path.write_text(json.dumps({**json.loads(original), **changed}))
            try:
                validate_completion_markers(run, marker_metadata)
            except ValidationError:
                pass
            else:
                raise AssertionError(f'accepted incorrect started marker {changed}')
            path.write_text(original)
        try:
            validate_completion_markers(run, {**marker_metadata, 'alloc_rounds': 4})
        except ValidationError:
            pass
        else:
            raise AssertionError('accepted conflicting allocation round aliases')
    print('Synthetic self-test passed: pairing, identities, failure rejection, deterministic CI, '
          'shared round blocks, allocation separation, zero denominators, private redaction, '
          'and required completion markers.')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('run', nargs='?', type=Path)
    parser.add_argument('--resamples', type=int, default=2000)
    parser.add_argument('--seed', type=int, default=20260914)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.run is None:
        parser.error('RUN is required unless --self-test is used')
    try:
        metadata = json.loads((args.run / 'metadata.json').read_text())
        rows = [json.loads(line) for line in (args.run / 'samples.jsonl').read_text().splitlines()
                if line.strip()]
        marker_hashes = validate_completion_markers(args.run, metadata)
        result = summarize(metadata, rows, args.resamples, args.seed)
        require(marker_hashes == validate_completion_markers(args.run, metadata),
                'completion markers changed during analysis')
        result['validation']['completion_markers_verified'] = True
        result['validation']['completion_marker_sha256'] = marker_hashes
        public = public_summary(result)
        contents = (json.dumps(result, indent=2, allow_nan=False) + '\n',
                    json.dumps(public, indent=2, allow_nan=False) + '\n', markdown(public))
        for name, content in zip(OUTPUT_NAMES, contents):
            atomic_write(args.run / name, content)
    except (ValidationError, OSError, json.JSONDecodeError, TypeError, KeyError) as error:
        # Do not leave a stale successful summary after a failed re-validation.
        for name in OUTPUT_NAMES:
            (args.run / name).unlink(missing_ok=True)
        print(f'Summary rejected: {error}', file=sys.stderr)
        return 2
    print(f"Validated {result['validation']['case_count']} cases; wrote local and anonymized reports.")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
