// Local native A/B runner. Build this identical source against each Go checkout.
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"time"

	"github.com/d2lang/d2/d2graph"
	"github.com/d2lang/d2/d2layouts/d2talalayout"
	"github.com/d2lang/d2/d2lib"
	"github.com/d2lang/d2/d2renderers/d2fonts"
	"github.com/d2lang/d2/d2renderers/d2svg"
	d2log "github.com/d2lang/d2/lib/log"
	"github.com/d2lang/d2/lib/textmeasure"
)

type config struct {
	InputPath      string          `json:"input_path"`
	UTF16Positions bool            `json:"utf16_positions"`
	Seed           int64           `json:"seed"`
	RootOnly       bool            `json:"root_only"`
	LayoutReuse    bool            `json:"layout_reuse"`
	FontDir        string          `json:"font_dir"`
	UseHostedFont  bool            `json:"use_hosted_font"`
	Render         json.RawMessage `json:"render"`
}

// Reuse the compiler ruler only when the checked-out renderer exposes its opt-in.
// Reflection keeps this benchmark source identical for old and new APIs; the
// production CLI assigns the field directly. Both branches remain measured.
func reuseCompilerRuler(render *d2svg.RenderOpts, ruler *textmeasure.Ruler) (bool, error) {
	field := reflect.ValueOf(render).Elem().FieldByName("Ruler")
	if !field.IsValid() {
		return false, nil
	}
	value := reflect.ValueOf(ruler)
	if !field.CanSet() || field.Type() != value.Type() {
		return false, fmt.Errorf("RenderOpts.Ruler has incompatible type or visibility")
	}
	field.Set(value)
	return true, nil
}

func run() (result map[string]any, err error) {
	result = map[string]any{"go_version": runtime.Version(), "gomaxprocs": runtime.GOMAXPROCS(0)}
	defer func() {
		if p := recover(); p != nil {
			err = fmt.Errorf("runner recovered panic: %v", p)
		}
	}()
	if len(os.Args) != 5 {
		return result, fmt.Errorf("expected input config output timing|alloc")
	}
	input, err := os.ReadFile(os.Args[1])
	if err != nil {
		return result, err
	}
	raw, err := os.ReadFile(os.Args[2])
	if err != nil {
		return result, err
	}
	var c config
	if err = json.Unmarshal(raw, &c); err != nil {
		return result, err
	}
	render := &d2svg.RenderOpts{}
	if err = json.Unmarshal(c.Render, render); err != nil {
		return result, err
	}
	mode := os.Args[4]
	if mode != "timing" && mode != "alloc" {
		return result, fmt.Errorf("invalid mode %q", mode)
	}
	var before, after runtime.MemStats
	if mode == "alloc" {
		runtime.ReadMemStats(&before)
	}
	start := time.Now()
	var font, mono *d2fonts.FontFamily
	if c.FontDir != "" {
		regular, e := os.ReadFile(filepath.Join(c.FontDir, "CircularStd-Book.ttf"))
		if e != nil {
			return result, e
		}
		bold, e := os.ReadFile(filepath.Join(c.FontDir, "CircularStd-Bold.ttf"))
		if e != nil {
			return result, e
		}
		hosted, e := d2fonts.AddFontFamily("d2Font", regular, regular, bold, bold)
		if e != nil {
			return result, e
		}
		if c.UseHostedFont {
			font = hosted
		}
		family := d2fonts.SourceCodePro
		mono = &family
	}
	ruler, err := textmeasure.NewRuler()
	if err != nil {
		return result, err
	}
	ready := time.Now()
	layout := "tala"
	tala := d2talalayout.Options{Seeds: []int64{c.Seed}, MaxConcurrency: 1}
	opts := &d2lib.CompileOptions{InputPath: c.InputPath, UTF16Pos: c.UTF16Positions, Ruler: ruler,
		FontFamily: font, MonoFontFamily: mono, Layout: &layout, LayoutReuse: c.LayoutReuse,
		LayoutResolver: func(engine string) (d2graph.LayoutGraph, error) {
			if engine != "tala" {
				return nil, fmt.Errorf("unexpected layout: %s", engine)
			}
			return func(ctx context.Context, g *d2graph.Graph) error { return d2talalayout.Layout(ctx, g, &tala) }, nil
		},
		RouterResolver: func(engine string) (d2graph.RouteEdges, error) {
			if engine != "tala" {
				return nil, fmt.Errorf("unexpected router: %s", engine)
			}
			return d2talalayout.RouteEdges, nil
		},
	}
	diagram, graph, err := d2lib.Compile(d2log.WithDefault(context.Background()), string(input), opts, render)
	if err != nil {
		return result, err
	}
	compiled := time.Now()
	rulerReused, err := reuseCompilerRuler(render, ruler)
	if err != nil {
		return result, err
	}
	var svg []byte
	if c.RootOnly {
		svg, err = d2svg.Render(diagram, render)
	} else {
		var boards [][]byte
		boards, err = d2svg.RenderMultiboard(diagram, render)
		if err == nil {
			if len(boards) != 1 {
				return result, fmt.Errorf("expected one board, got %d", len(boards))
			}
			svg = boards[0]
		}
	}
	if err != nil {
		return result, err
	}
	rendered := time.Now()
	if mode == "alloc" {
		runtime.ReadMemStats(&after)
		result["alloc_bytes"] = after.TotalAlloc - before.TotalAlloc
		result["alloc_objects"] = after.Mallocs - before.Mallocs
		result["gc_cycles"] = after.NumGC - before.NumGC
		result["gc_pause_ns"] = after.PauseTotalNs - before.PauseTotalNs
	}
	runtime.KeepAlive(graph)
	runtime.KeepAlive(diagram)
	runtime.KeepAlive(svg)
	if err = os.WriteFile(os.Args[3], svg, 0600); err != nil {
		return result, err
	}
	result["setup_ms"] = float64(ready.Sub(start)) / 1e6
	result["compile_layout_ms"] = float64(compiled.Sub(ready)) / 1e6
	result["render_ms"] = float64(rendered.Sub(compiled)) / 1e6
	result["pipeline_ms"] = float64(rendered.Sub(start)) / 1e6
	result["svg_bytes"] = len(svg)
	result["ruler_reused"] = rulerReused
	return result, nil
}
func main() {
	result, err := run()
	if err != nil {
		result["error"] = err.Error()
	}
	if e := json.NewEncoder(os.Stdout).Encode(result); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(2)
	}
	if err != nil {
		os.Exit(1)
	}
}
