# Go A/B measurements

Comparison: cumulative. 7 cases; 20 measured paired rounds; 3 allocation paired rounds.

All samples passed exit, timeout, paired-round, identity, and exact SVG checks. Only preflight-success cases in this selected run are represented; consult the local preflight report for excluded or failed cases.

Ratios are candidate / baseline; lower values indicate lower resource use. Brackets show 95% paired percentile bootstrap intervals (2,000 resamples; seed 20260914). Whole round blocks are shared across cases. Intervals are unadjusted for multiple comparisons and describe these fixed cases. An interval containing 1 is inconclusive. These results make no automatic keep/drop decision.

Allocation counters come from separate instrumented runs. Peak RSS is process memory. Public and private groups are reported separately; the all-cases result is descriptive and does not substitute for either group.

## Group wall time

| Group | Cases | Baseline total ms | Candidate total ms | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | ---: | ---: | ---: | --- | --- |
| public | 1 | 24.998 | 25.001 | 1.000 [0.983, 1.010] | 1.000 [0.983, 1.010] |
| private | 6 | 362.329 | 360.678 | 0.995 [0.993, 1.000] | 0.993 [0.989, 1.000] |
| all | 7 | 387.327 | 385.679 | 0.996 [0.993, 1.000] | 0.994 [0.990, 1.000] |

Totals above are sums of per-case medians; they are not one pooled median.

## Group CPU, memory, and pipeline stages

| Group | Metric | Ratio of sums of case medians [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | --- | --- |
| public | cpu_ms | 0.972 [0.954, 1.011] | 0.972 [0.954, 1.011] |
| public | user_ms | 0.984 [0.963, 1.012] | 0.984 [0.963, 1.012] |
| public | system_ms | 0.975 [0.938, 1.018] | 0.975 [0.938, 1.018] |
| public | peak_rss_mib | 0.988 [0.981, 0.999] | 0.988 [0.981, 0.999] |
| public | setup_ms | 1.018 [0.792, 1.249] | 1.018 [0.792, 1.249] |
| public | compile_layout_ms | 1.000 [0.978, 1.013] | 1.000 [0.978, 1.013] |
| public | render_ms | 1.014 [0.935, 1.142] | 1.014 [0.935, 1.142] |
| public | pipeline_ms | 1.009 [0.993, 1.025] | 1.009 [0.993, 1.025] |
| private | cpu_ms | 0.993 [0.989, 0.999] | 0.986 [0.979, 0.995] |
| private | user_ms | 0.994 [0.992, 1.000] | 0.985 [0.983, 0.996] |
| private | system_ms | 0.989 [0.973, 1.006] | 0.984 [0.971, 0.999] |
| private | peak_rss_mib | 0.997 [0.992, 1.002] | 0.997 [0.991, 1.001] |
| private | setup_ms | 0.997 [0.980, 1.010] | 0.997 [0.980, 1.010] |
| private | compile_layout_ms | 1.002 [0.997, 1.005] | 1.006 [0.988, 1.014] |
| private | render_ms | 0.974 [0.904, 1.041] | 0.956 [0.873, 1.036] |
| private | pipeline_ms | 0.998 [0.994, 1.001] | 0.994 [0.984, 1.002] |
| all | cpu_ms | 0.992 [0.988, 0.999] | 0.984 [0.978, 0.994] |
| all | user_ms | 0.994 [0.991, 1.000] | 0.985 [0.982, 0.996] |
| all | system_ms | 0.988 [0.973, 1.004] | 0.983 [0.971, 0.997] |
| all | peak_rss_mib | 0.996 [0.991, 1.000] | 0.995 [0.990, 1.000] |
| all | setup_ms | 0.997 [0.979, 1.010] | 1.000 [0.962, 1.034] |
| all | compile_layout_ms | 1.002 [0.997, 1.005] | 1.005 [0.990, 1.012] |
| all | render_ms | 0.980 [0.922, 1.037] | 0.964 [0.894, 1.033] |
| all | pipeline_ms | 0.998 [0.994, 1.001] | 0.996 [0.988, 1.003] |

## Per-case measurements

| Case | Baseline wall ms | Candidate wall ms | Wall ratio [95% CI] | CPU ratio [95% CI] | RSS ratio [95% CI] |
| --- | ---: | ---: | --- | --- | --- |
| public/jupyter_aws_eks | 24.998 | 25.001 | 1.000 [0.983, 1.010] | 0.972 [0.954, 1.011] | 0.988 [0.981, 0.999] |
| private-0034 | 20.676 | 20.212 | 0.978 [0.958, 1.010] | 0.948 [0.926, 0.990] | 0.988 [0.979, 1.002] |
| private-0049 | 63.198 | 62.639 | 0.991 [0.983, 1.000] | 0.991 [0.977, 1.010] | 1.002 [0.988, 1.012] |
| private-0058 | 53.726 | 53.302 | 0.992 [0.979, 1.008] | 0.993 [0.973, 1.011] | 0.991 [0.980, 1.001] |
| private-0160 | 112.439 | 112.431 | 1.000 [0.993, 1.005] | 1.000 [0.991, 1.011] | 1.003 [0.992, 1.014] |
| private-0179 | 20.850 | 20.804 | 0.998 [0.974, 1.017] | 0.985 [0.953, 1.020] | 0.985 [0.972, 0.999] |
| private-0191 | 91.439 | 91.291 | 0.998 [0.992, 1.012] | 0.999 [0.990, 1.010] | 1.011 [0.989, 1.029] |

## Allocation counters

| Group | Counter | Baseline sum of medians | Candidate sum of medians | Ratio [95% CI] |
| --- | --- | ---: | ---: | --- |
| public | alloc_bytes | 8,553,960 | 8,557,808 | 1.000 [0.999, 1.002] |
| public | alloc_objects | 95,831 | 95,840 | 1.000 [1.000, 1.000] |
| public | gc_cycles | 2 | 2 | 1.000 [1.000, 1.000] |
| private | alloc_bytes | 79,352,816 | 79,133,648 | 0.997 [0.973, 0.997] |
| private | alloc_objects | 809,039 | 804,031 | 0.994 [0.994, 0.994] |
| private | gc_cycles | 18 | 17 | 0.944 [0.941, 1.000] |
| all | alloc_bytes | 87,906,776 | 87,691,456 | 0.998 [0.976, 0.998] |
| all | alloc_objects | 904,870 | 899,871 | 0.994 [0.994, 0.995] |
| all | gc_cycles | 20 | 19 | 0.950 [0.947, 1.000] |

Full stage, CPU, RSS, allocation, range, and IQR statistics are in public-summary.json. Private rows use opaque IDs.
