#!/usr/bin/env python3
"""Dated public-only reproduction for this evidence bundle, not a maintained benchmark framework."""
import argparse, hashlib, json, os, platform, random, signal, subprocess, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(path, value): path.write_text(json.dumps(value, indent=2)+'\n')
def append(path, value):
    with path.open('a') as f: f.write(json.dumps(value)+'\n')

def run_child(case, binary, binary_hash, label, out, phase, r, mode, oracle, env):
    folder=out/'outputs'/case['id']; folder.mkdir(parents=True,exist_ok=True)
    svg=folder/(label+'.svg'); svg.unlink(missing_ok=True)
    stdout,stderr=folder/(label+'.json'),folder/(label+'.stderr')
    with stdout.open('wb') as so,stderr.open('wb') as se:
        start=time.perf_counter_ns()
        p=subprocess.Popen([str(binary),case['input_path'],case['config_path'],str(svg),mode],env=env,stdout=so,stderr=se,start_new_session=True)
        def timeout(signum,frame): raise TimeoutError()
        previous=signal.signal(signal.SIGALRM,timeout); signal.setitimer(signal.ITIMER_REAL,120); timed_out=False
        try: _,status,usage=os.wait4(p.pid,0)
        except TimeoutError:
            timed_out=True; os.killpg(p.pid,signal.SIGKILL); _,status,usage=os.wait4(p.pid,0)
        finally: signal.setitimer(signal.ITIMER_REAL,0); signal.signal(signal.SIGALRM,previous)
        elapsed=(time.perf_counter_ns()-start)/1e6; p.returncode=os.waitstatus_to_exitcode(status)
    actual=sha(svg) if svg.exists() else None
    stages=json.loads(stdout.read_text()) if stdout.stat().st_size else {}
    row={'case':case['id'],'variant':label,'phase':phase,'round':r,'mode':mode,
         'binary_sha256':binary_hash,'input_sha256':case['input_sha256'],'config_sha256':case['config_sha256'],
         'wall_ms':elapsed,'cpu_ms':(usage.ru_utime+usage.ru_stime)*1000,'user_ms':usage.ru_utime*1000,'system_ms':usage.ru_stime*1000,
         'peak_rss_mib':usage.ru_maxrss*(1 if platform.system()=='Darwin' else 1024)/1024**2,
         'returncode':p.returncode,'timed_out':timed_out,'svg_sha256':actual,'oracle_sha256':oracle,
         'svg_exact':p.returncode==0 and not timed_out and oracle is not None and actual==oracle,'stages':stages}
    if p.returncode: row['error']=stages.get('error',stderr.read_text())
    return row

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True)
    p.add_argument('--source',type=Path,required=True,help='Go repository containing e2etests/testdata/files')
    p.add_argument('--out',type=Path,required=True);p.add_argument('--rounds',type=int,default=10)
    p.add_argument('--warmups',type=int,default=2);p.add_argument('--seed',type=int,default=20260914)
    p.add_argument('--comparison',choices=('incremental','cumulative'),default='incremental',help='Label the chosen source comparison; does not change the measurement protocol')
    a=p.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    binaries={'baseline':a.baseline.resolve(),'candidate':a.candidate.resolve()};hashes={k:sha(v) for k,v in binaries.items()}
    cases=[]
    for item in json.loads((HERE/'public-workloads.json').read_text()):
        source=(a.source/item['source']).resolve()
        if sha(source)!=item['input_sha256']:raise ValueError('Public input differs: '+item['id'])
        config=out/(item['id'].split('/')[1]+'.json');write(config,item['config'])
        cases.append({'id':item['id'],'public_id':item['id'],'private':False,'group':'public','tags':item['tags'],
            'input_path':str(source),'input_sha256':sha(source),'config_path':str(config),'config_sha256':sha(config)})
    env=os.environ.copy()
    for k in ('GOMAXPROCS','GOGC','GOMEMLIMIT','GODEBUG','GOEXPERIMENT'):env.pop(k,None)
    env['LC_ALL']='C'
    for index,case in enumerate(cases):
        labels=list(binaries) if index%2==0 else list(reversed(binaries));pair={}
        for label in labels:
            row=run_child(case,binaries[label],hashes[label],label,out,'preflight',0,'timing',None,env)
            append(out/'preflight.jsonl',row);pair[label]=row
        if any(r['returncode'] or r['timed_out'] for r in pair.values()) or pair['baseline']['svg_sha256']!=pair['candidate']['svg_sha256']:
            raise ValueError('Preflight failed: '+case['id'])
        case['oracle_sha256']=pair['baseline']['svg_sha256']
    meta={'baseline':'baseline','candidate':'candidate','comparison':a.comparison,'cases':cases,'binary_hashes':hashes,
          'rounds':a.rounds,'warmups':a.warmups,'allocation_rounds':3,'order_seed':a.seed}
    write(out/'metadata.json',meta)
    for phase,rounds,warmups,mode in [('measured',a.rounds,a.warmups,'timing'),('alloc',3,0,'alloc')]:
        write(out/(phase+'-started.json'),{'cases':[c['id'] for c in cases],'rounds':rounds,'warmups':warmups,'order_seed':a.seed})
        rng=random.Random(a.seed)
        offsets={c['id']:int(hashlib.sha256((str(a.seed)+c['id']).encode()).hexdigest()[-1],16)%2 for c in cases}
        for r in range(-warmups,rounds):
            order=cases.copy();rng.shuffle(order)
            for case in order:
                labels=list(binaries) if (r+offsets[case['id']])%2==0 else list(reversed(binaries))
                for label in labels:
                    row=run_child(case,binaries[label],hashes[label],label,out,'warmup' if r<0 else phase,r,mode,case['oracle_sha256'],env)
                    row['pair_order']=labels;append(out/'samples.jsonl',row)
                    if not row['svg_exact']:raise ValueError('Output changed: '+case['id'])
            print(phase,r,flush=True)
        if any(sha(binaries[k])!=h for k,h in hashes.items()):raise ValueError('Binary changed')
        if any(sha(c['input_path'])!=c['input_sha256'] or sha(c['config_path'])!=c['config_sha256'] for c in cases):raise ValueError('Input changed')
        write(out/(phase+'-complete.json'),{'pairs':len(cases)*rounds,'input_identities_unchanged':True,'binary_identities_unchanged':True})
    print('Complete; run frozen/summarize.py against the output directory.')

if __name__=='__main__':main()
