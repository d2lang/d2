# Go A/B measurements

Comparison: incremental. 2 cases; 20 measured paired rounds; 3 allocation paired rounds.

All samples passed exit, timeout, paired-round, identity, and exact SVG checks. Only preflight-success cases in this selected run are represented; consult the local preflight report for excluded or failed cases.

Ratios are candidate / baseline; lower values indicate lower resource use. Brackets show 95% paired percentile bootstrap intervals (2,000 resamples; seed 20260916). Whole round blocks are shared across cases. Intervals are unadjusted for multiple comparisons and describe these fixed cases. An interval containing 1 is inconclusive. These results make no automatic keep/drop decision.

Allocation counters come from separate instrumented runs. Peak RSS is process memory. Public and private groups are reported separately; the all-cases result is descriptive and does not substitute for either group.

## Group wall time

| Group | Cases | Baseline total ms | Candidate total ms | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | ---: | ---: | ---: | --- | --- |
| private | 2 | 65.176 | 65.477 | 1.005 [0.986, 1.016] | 1.006 [0.988, 1.018] |
| all | 2 | 65.176 | 65.477 | 1.005 [0.986, 1.016] | 1.006 [0.988, 1.018] |

Totals above are sums of per-case medians; they are not one pooled median.

## Group CPU, memory, and pipeline stages

| Group | Metric | Ratio of sums of case medians [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | --- | --- |
| private | cpu_ms | 1.000 [0.978, 1.017] | 1.003 [0.978, 1.020] |
| private | user_ms | 0.999 [0.985, 1.021] | 1.000 [0.988, 1.021] |
| private | system_ms | 0.991 [0.930, 1.034] | 0.991 [0.930, 1.036] |
| private | peak_rss_mib | 1.001 [0.993, 1.006] | 1.001 [0.993, 1.006] |
| private | setup_ms | 0.988 [0.957, 1.030] | 0.988 [0.957, 1.030] |
| private | compile_layout_ms | 1.020 [0.992, 1.037] | 1.027 [0.985, 1.060] |
| private | render_ms | 0.944 [0.827, 1.028] | 0.948 [0.826, 1.029] |
| private | pipeline_ms | 0.997 [0.974, 1.020] | 1.001 [0.972, 1.028] |
| all | cpu_ms | 1.000 [0.978, 1.017] | 1.003 [0.978, 1.020] |
| all | user_ms | 0.999 [0.985, 1.021] | 1.000 [0.988, 1.021] |
| all | system_ms | 0.991 [0.930, 1.034] | 0.991 [0.930, 1.036] |
| all | peak_rss_mib | 1.001 [0.993, 1.006] | 1.001 [0.993, 1.006] |
| all | setup_ms | 0.988 [0.957, 1.030] | 0.988 [0.957, 1.030] |
| all | compile_layout_ms | 1.020 [0.992, 1.037] | 1.027 [0.985, 1.060] |
| all | render_ms | 0.944 [0.827, 1.028] | 0.948 [0.826, 1.029] |
| all | pipeline_ms | 0.997 [0.974, 1.020] | 1.001 [0.972, 1.028] |

## Per-case measurements

| Case | Baseline wall ms | Candidate wall ms | Wall ratio [95% CI] | CPU ratio [95% CI] | RSS ratio [95% CI] |
| --- | ---: | ---: | --- | --- | --- |
| private-0218 | 38.917 | 38.881 | 0.999 [0.972, 1.010] | 0.989 [0.967, 1.008] | 1.003 [0.988, 1.010] |
| private-0223 | 26.259 | 26.595 | 1.013 [0.994, 1.029] | 1.017 [0.975, 1.041] | 0.999 [0.992, 1.007] |

## Allocation counters

| Group | Counter | Baseline sum of medians | Candidate sum of medians | Ratio [95% CI] |
| --- | --- | ---: | ---: | --- |
| private | alloc_bytes | 14,377,344 | 13,182,152 | 0.917 [0.843, 0.995] |
| private | alloc_objects | 64,773 | 64,757 | 1.000 [0.999, 1.000] |
| private | gc_cycles | 3 | 3 | 1.000 [0.667, 1.000] |
| all | alloc_bytes | 14,377,344 | 13,182,152 | 0.917 [0.843, 0.995] |
| all | alloc_objects | 64,773 | 64,757 | 1.000 [0.999, 1.000] |
| all | gc_cycles | 3 | 3 | 1.000 [0.667, 1.000] |

Full stage, CPU, RSS, allocation, range, and IQR statistics are in public-summary.json. Private rows use opaque IDs.
