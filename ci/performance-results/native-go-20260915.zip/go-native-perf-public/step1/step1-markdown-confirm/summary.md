# Go A/B measurements

Comparison: incremental. 24 cases; 20 measured paired rounds; 3 allocation paired rounds.

All samples passed exit, timeout, paired-round, identity, and exact SVG checks. Only preflight-success cases in this selected run are represented; consult the local preflight report for excluded or failed cases.

Ratios are candidate / baseline; lower values indicate lower resource use. Brackets show 95% paired percentile bootstrap intervals (2,000 resamples; seed 20260915). Whole round blocks are shared across cases. Intervals are unadjusted for multiple comparisons and describe these fixed cases. An interval containing 1 is inconclusive. These results make no automatic keep/drop decision.

Allocation counters come from separate instrumented runs. Peak RSS is process memory. Public and private groups are reported separately; the all-cases result is descriptive and does not substitute for either group.

## Group wall time

| Group | Cases | Baseline total ms | Candidate total ms | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | ---: | ---: | ---: | --- | --- |
| public | 4 | 436.890 | 433.364 | 0.992 [0.987, 0.996] | 0.990 [0.985, 0.995] |
| private | 20 | 1,046.855 | 1,040.348 | 0.994 [0.991, 0.996] | 0.992 [0.990, 0.995] |
| all | 24 | 1,483.745 | 1,473.712 | 0.993 [0.991, 0.996] | 0.992 [0.989, 0.994] |

Totals above are sums of per-case medians; they are not one pooled median.

## Group CPU, memory, and pipeline stages

| Group | Metric | Ratio of sums of case medians [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | --- | --- |
| public | cpu_ms | 0.991 [0.988, 0.998] | 0.988 [0.984, 0.995] |
| public | user_ms | 0.992 [0.990, 0.998] | 0.989 [0.986, 0.995] |
| public | system_ms | 0.979 [0.962, 0.997] | 0.980 [0.962, 0.997] |
| public | peak_rss_mib | 0.997 [0.991, 1.002] | 0.997 [0.991, 1.002] |
| public | setup_ms | 0.978 [0.923, 1.031] | 0.978 [0.924, 1.031] |
| public | compile_layout_ms | 0.993 [0.987, 0.996] | 0.990 [0.984, 0.993] |
| public | render_ms | 1.020 [0.997, 1.042] | 1.017 [0.994, 1.040] |
| public | pipeline_ms | 0.993 [0.988, 0.996] | 0.989 [0.985, 0.994] |
| private | cpu_ms | 0.993 [0.990, 0.997] | 0.991 [0.987, 0.996] |
| private | user_ms | 0.993 [0.990, 0.996] | 0.990 [0.986, 0.993] |
| private | system_ms | 0.993 [0.983, 1.003] | 0.995 [0.983, 1.005] |
| private | peak_rss_mib | 0.996 [0.993, 0.999] | 0.996 [0.993, 0.999] |
| private | setup_ms | 1.002 [0.995, 1.011] | 1.002 [0.995, 1.011] |
| private | compile_layout_ms | 0.990 [0.986, 0.993] | 0.944 [0.938, 0.950] |
| private | render_ms | 0.998 [0.982, 1.015] | 0.995 [0.977, 1.013] |
| private | pipeline_ms | 0.992 [0.989, 0.995] | 0.982 [0.978, 0.985] |
| all | cpu_ms | 0.992 [0.990, 0.996] | 0.991 [0.987, 0.995] |
| all | user_ms | 0.993 [0.991, 0.996] | 0.990 [0.987, 0.993] |
| all | system_ms | 0.990 [0.981, 0.997] | 0.992 [0.982, 1.000] |
| all | peak_rss_mib | 0.996 [0.994, 0.999] | 0.996 [0.994, 0.999] |
| all | setup_ms | 1.002 [0.995, 1.011] | 0.998 [0.986, 1.011] |
| all | compile_layout_ms | 0.991 [0.987, 0.994] | 0.952 [0.946, 0.956] |
| all | render_ms | 1.004 [0.991, 1.018] | 0.999 [0.983, 1.015] |
| all | pipeline_ms | 0.992 [0.990, 0.995] | 0.983 [0.980, 0.986] |

## Tagged wall time

| Tag | Group | Cases | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | ---: | --- | --- |
| legend | public | 2 | 0.988 [0.981, 0.994] | 0.987 [0.979, 0.994] |
| legend | all | 2 | 0.988 [0.981, 0.994] | 0.987 [0.979, 0.994] |
| markdown | public | 4 | 0.992 [0.987, 0.996] | 0.990 [0.985, 0.995] |
| markdown | private | 20 | 0.994 [0.991, 0.996] | 0.992 [0.990, 0.995] |
| markdown | all | 24 | 0.993 [0.991, 0.996] | 0.992 [0.989, 0.994] |

## Per-case measurements

| Case | Baseline wall ms | Candidate wall ms | Wall ratio [95% CI] | CPU ratio [95% CI] | RSS ratio [95% CI] |
| --- | ---: | ---: | --- | --- | --- |
| public/fulcro_rad | 102.695 | 101.214 | 0.986 [0.979, 0.997] | 0.987 [0.976, 0.999] | 0.996 [0.985, 1.005] |
| public/lion_reader_frontend | 82.668 | 82.402 | 0.997 [0.990, 1.002] | 0.997 [0.989, 1.009] | 0.993 [0.978, 1.006] |
| public/mocha_soc | 181.598 | 181.406 | 0.999 [0.991, 1.005] | 0.998 [0.993, 1.006] | 1.006 [0.986, 1.019] |
| public/spyre_encoder | 69.928 | 68.343 | 0.977 [0.963, 0.991] | 0.972 [0.959, 0.990] | 0.993 [0.987, 1.001] |
| private-0017 | 36.454 | 34.921 | 0.958 [0.948, 0.970] | 0.948 [0.918, 0.967] | 0.984 [0.955, 1.005] |
| private-0043 | 85.845 | 85.481 | 0.996 [0.990, 1.004] | 0.996 [0.989, 1.004] | 0.994 [0.988, 1.006] |
| private-0045 | 18.134 | 17.826 | 0.983 [0.962, 1.012] | 0.983 [0.960, 1.012] | 0.996 [0.983, 1.008] |
| private-0050 | 108.298 | 107.750 | 0.995 [0.984, 1.008] | 0.991 [0.972, 1.010] | 0.982 [0.974, 0.993] |
| private-0052 | 249.063 | 247.932 | 0.995 [0.990, 1.004] | 0.996 [0.991, 1.004] | 1.000 [0.978, 1.027] |
| private-0063 | 64.468 | 64.428 | 0.999 [0.990, 1.011] | 1.001 [0.992, 1.014] | 0.996 [0.989, 1.006] |
| private-0083 | 33.696 | 33.538 | 0.995 [0.985, 1.007] | 0.996 [0.988, 1.008] | 0.999 [0.991, 1.005] |
| private-0093 | 32.609 | 32.391 | 0.993 [0.985, 1.001] | 0.985 [0.969, 1.011] | 0.991 [0.981, 1.010] |
| private-0098 | 20.948 | 21.321 | 1.018 [0.992, 1.031] | 1.016 [0.963, 1.042] | 0.995 [0.984, 1.009] |
| private-0122 | 47.336 | 46.874 | 0.990 [0.975, 1.006] | 0.989 [0.977, 1.010] | 0.998 [0.982, 1.009] |
| private-0140 | 32.601 | 32.284 | 0.990 [0.972, 0.999] | 0.970 [0.954, 1.009] | 0.990 [0.982, 1.002] |
| private-0156 | 38.422 | 37.725 | 0.982 [0.973, 0.992] | 0.997 [0.977, 1.010] | 0.999 [0.993, 1.008] |
| private-0203 | 99.471 | 99.315 | 0.998 [0.994, 1.003] | 1.000 [0.993, 1.010] | 0.998 [0.980, 1.021] |
| private-0205 | 28.394 | 27.929 | 0.984 [0.965, 0.995] | 0.973 [0.962, 0.989] | 1.006 [0.997, 1.009] |
| private-0207 | 24.311 | 24.385 | 1.003 [0.988, 1.028] | 1.024 [0.991, 1.056] | 1.015 [1.006, 1.020] |
| private-0208 | 24.635 | 24.780 | 1.006 [0.992, 1.020] | 1.003 [0.988, 1.019] | 0.993 [0.983, 1.000] |
| private-0212 | 25.897 | 25.689 | 0.992 [0.974, 1.009] | 0.992 [0.975, 1.015] | 0.992 [0.983, 1.000] |
| private-0221 | 20.036 | 19.820 | 0.989 [0.967, 1.010] | 0.976 [0.930, 1.023] | 0.984 [0.969, 0.998] |
| private-0227 | 35.839 | 35.953 | 1.003 [0.988, 1.016] | 1.001 [0.984, 1.011] | 1.005 [0.993, 1.017] |
| private-0232 | 20.399 | 20.006 | 0.981 [0.961, 1.004] | 0.986 [0.963, 1.002] | 0.999 [0.987, 1.007] |

## Allocation counters

| Group | Counter | Baseline sum of medians | Candidate sum of medians | Ratio [95% CI] |
| --- | --- | ---: | ---: | --- |
| public | alloc_bytes | 103,389,616 | 101,651,320 | 0.983 [0.972, 0.993] |
| public | alloc_objects | 1,237,090 | 1,227,405 | 0.992 [0.992, 0.992] |
| public | gc_cycles | 25 | 26 | 1.040 [0.962, 1.040] |
| private | alloc_bytes | 283,440,848 | 277,230,904 | 0.978 [0.955, 0.983] |
| private | alloc_objects | 2,395,797 | 2,367,012 | 0.988 [0.988, 0.988] |
| private | gc_cycles | 64 | 60 | 0.938 [0.909, 0.984] |
| all | alloc_bytes | 386,830,464 | 378,882,224 | 0.979 [0.959, 0.986] |
| all | alloc_objects | 3,632,887 | 3,594,417 | 0.989 [0.989, 0.989] |
| all | gc_cycles | 89 | 86 | 0.966 [0.924, 1.000] |

Full stage, CPU, RSS, allocation, range, and IQR statistics are in public-summary.json. Private rows use opaque IDs.
