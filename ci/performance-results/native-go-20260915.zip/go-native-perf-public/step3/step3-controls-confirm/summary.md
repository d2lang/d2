# Go A/B measurements

Comparison: incremental. 10 cases; 20 measured paired rounds; 3 allocation paired rounds.

All samples passed exit, timeout, paired-round, identity, and exact SVG checks. Only preflight-success cases in this selected run are represented; consult the local preflight report for excluded or failed cases.

Ratios are candidate / baseline; lower values indicate lower resource use. Brackets show 95% paired percentile bootstrap intervals (2,000 resamples; seed 20260914). Whole round blocks are shared across cases. Intervals are unadjusted for multiple comparisons and describe these fixed cases. An interval containing 1 is inconclusive. These results make no automatic keep/drop decision.

Allocation counters come from separate instrumented runs. Peak RSS is process memory. Public and private groups are reported separately; the all-cases result is descriptive and does not substitute for either group.

## Group wall time

| Group | Cases | Baseline total ms | Candidate total ms | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | ---: | ---: | ---: | --- | --- |
| public | 1 | 28.916 | 28.696 | 0.992 [0.968, 1.016] | 0.992 [0.968, 1.016] |
| private | 9 | 302.587 | 301.886 | 0.998 [0.994, 1.004] | 0.996 [0.991, 1.001] |
| all | 10 | 331.503 | 330.582 | 0.997 [0.993, 1.003] | 0.996 [0.990, 1.001] |

Totals above are sums of per-case medians; they are not one pooled median.

## Group CPU, memory, and pipeline stages

| Group | Metric | Ratio of sums of case medians [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | --- | --- |
| public | cpu_ms | 0.982 [0.968, 1.001] | 0.982 [0.968, 1.001] |
| public | user_ms | 0.987 [0.972, 1.003] | 0.987 [0.972, 1.003] |
| public | system_ms | 0.984 [0.942, 1.020] | 0.984 [0.942, 1.020] |
| public | peak_rss_mib | 1.002 [0.990, 1.015] | 1.002 [0.990, 1.015] |
| public | setup_ms | 1.065 [0.947, 1.194] | 1.065 [0.947, 1.194] |
| public | compile_layout_ms | 0.990 [0.972, 1.015] | 0.990 [0.972, 1.015] |
| public | render_ms | 0.937 [0.896, 1.039] | 0.937 [0.896, 1.039] |
| public | pipeline_ms | 0.988 [0.969, 1.009] | 0.988 [0.969, 1.009] |
| private | cpu_ms | 1.000 [0.994, 1.006] | 0.999 [0.991, 1.008] |
| private | user_ms | 1.000 [0.995, 1.006] | 0.999 [0.992, 1.009] |
| private | system_ms | 0.986 [0.969, 1.015] | 0.984 [0.967, 1.013] |
| private | peak_rss_mib | 1.001 [0.998, 1.006] | 1.001 [0.998, 1.006] |
| private | setup_ms | 0.997 [0.986, 1.007] | 0.997 [0.986, 1.007] |
| private | compile_layout_ms | 1.000 [0.995, 1.008] | 0.997 [0.983, 1.017] |
| private | render_ms | 1.015 [0.966, 1.055] | 1.006 [0.964, 1.051] |
| private | pipeline_ms | 1.001 [0.996, 1.007] | 0.998 [0.989, 1.007] |
| all | cpu_ms | 0.999 [0.993, 1.004] | 0.998 [0.990, 1.006] |
| all | user_ms | 0.999 [0.993, 1.005] | 0.998 [0.991, 1.007] |
| all | system_ms | 0.986 [0.969, 1.014] | 0.984 [0.968, 1.011] |
| all | peak_rss_mib | 1.001 [0.998, 1.005] | 1.001 [0.998, 1.005] |
| all | setup_ms | 0.997 [0.987, 1.007] | 1.003 [0.989, 1.019] |
| all | compile_layout_ms | 0.999 [0.995, 1.006] | 0.997 [0.984, 1.015] |
| all | render_ms | 1.001 [0.961, 1.040] | 0.999 [0.961, 1.041] |
| all | pipeline_ms | 1.000 [0.995, 1.005] | 0.997 [0.989, 1.005] |

## Per-case measurements

| Case | Baseline wall ms | Candidate wall ms | Wall ratio [95% CI] | CPU ratio [95% CI] | RSS ratio [95% CI] |
| --- | ---: | ---: | --- | --- | --- |
| public/jupyter_k8s_oidc | 28.916 | 28.696 | 0.992 [0.968, 1.016] | 0.982 [0.968, 1.001] | 1.002 [0.990, 1.015] |
| private-0019 | 116.991 | 117.078 | 1.001 [0.994, 1.012] | 1.000 [0.993, 1.009] | 1.002 [0.995, 1.012] |
| private-0037 | 19.744 | 20.065 | 1.016 [0.986, 1.026] | 1.011 [0.980, 1.051] | 1.006 [0.994, 1.013] |
| private-0053 | 19.636 | 19.370 | 0.986 [0.965, 1.013] | 0.992 [0.947, 1.015] | 1.001 [0.992, 1.008] |
| private-0056 | 35.003 | 34.759 | 0.993 [0.977, 1.004] | 1.004 [0.989, 1.013] | 0.996 [0.985, 1.012] |
| private-0078 | 23.686 | 23.794 | 1.005 [0.983, 1.021] | 1.013 [0.990, 1.036] | 1.008 [1.004, 1.014] |
| private-0124 | 19.799 | 19.533 | 0.987 [0.966, 1.013] | 0.972 [0.953, 1.017] | 0.990 [0.979, 1.003] |
| private-0139 | 20.590 | 20.400 | 0.991 [0.970, 1.018] | 1.006 [0.953, 1.041] | 1.008 [0.991, 1.023] |
| private-0177 | 27.336 | 27.462 | 1.005 [0.991, 1.019] | 1.012 [0.985, 1.036] | 1.002 [0.993, 1.017] |
| private-0214 | 19.803 | 19.426 | 0.981 [0.963, 1.009] | 0.986 [0.963, 1.021] | 0.998 [0.990, 1.011] |

## Allocation counters

| Group | Counter | Baseline sum of medians | Candidate sum of medians | Ratio [95% CI] |
| --- | --- | ---: | ---: | --- |
| public | alloc_bytes | 10,285,336 | 10,291,760 | 1.001 [0.993, 1.001] |
| public | alloc_objects | 119,590 | 119,595 | 1.000 [1.000, 1.000] |
| public | gc_cycles | 3 | 3 | 1.000 [0.667, 1.000] |
| private | alloc_bytes | 97,760,896 | 97,696,272 | 0.999 [0.976, 1.024] |
| private | alloc_objects | 647,229 | 647,210 | 1.000 [1.000, 1.000] |
| private | gc_cycles | 19 | 19 | 1.000 [1.000, 1.056] |
| all | alloc_bytes | 108,046,232 | 107,988,032 | 0.999 [0.978, 1.021] |
| all | alloc_objects | 766,819 | 766,805 | 1.000 [1.000, 1.000] |
| all | gc_cycles | 22 | 22 | 1.000 [1.000, 1.045] |

Full stage, CPU, RSS, allocation, range, and IQR statistics are in public-summary.json. Private rows use opaque IDs.
