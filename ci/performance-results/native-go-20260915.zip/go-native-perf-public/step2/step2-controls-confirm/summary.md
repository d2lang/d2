# Go A/B measurements

Comparison: incremental. 6 cases; 20 measured paired rounds; 3 allocation paired rounds.

All samples passed exit, timeout, paired-round, identity, and exact SVG checks. Only preflight-success cases in this selected run are represented; consult the local preflight report for excluded or failed cases.

Ratios are candidate / baseline; lower values indicate lower resource use. Brackets show 95% paired percentile bootstrap intervals (2,000 resamples; seed 20260914). Whole round blocks are shared across cases. Intervals are unadjusted for multiple comparisons and describe these fixed cases. An interval containing 1 is inconclusive. These results make no automatic keep/drop decision.

Allocation counters come from separate instrumented runs. Peak RSS is process memory. Public and private groups are reported separately; the all-cases result is descriptive and does not substitute for either group.

## Group wall time

| Group | Cases | Baseline total ms | Candidate total ms | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | ---: | ---: | ---: | --- | --- |
| private | 6 | 278.441 | 277.234 | 0.996 [0.991, 1.002] | 0.994 [0.988, 1.001] |
| all | 6 | 278.441 | 277.234 | 0.996 [0.991, 1.002] | 0.994 [0.988, 1.001] |

Totals above are sums of per-case medians; they are not one pooled median.

## Group CPU, memory, and pipeline stages

| Group | Metric | Ratio of sums of case medians [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | --- | --- |
| private | cpu_ms | 0.996 [0.989, 1.006] | 0.994 [0.985, 1.004] |
| private | user_ms | 0.999 [0.994, 1.005] | 0.998 [0.991, 1.005] |
| private | system_ms | 0.995 [0.963, 1.020] | 0.991 [0.963, 1.018] |
| private | peak_rss_mib | 0.997 [0.991, 1.003] | 0.998 [0.991, 1.003] |
| private | setup_ms | 0.997 [0.983, 1.017] | 0.997 [0.983, 1.017] |
| private | compile_layout_ms | 1.001 [0.994, 1.005] | 1.002 [0.984, 1.016] |
| private | render_ms | 1.057 [0.964, 1.169] | 1.049 [0.953, 1.158] |
| private | pipeline_ms | 1.001 [0.996, 1.005] | 0.999 [0.992, 1.005] |
| all | cpu_ms | 0.996 [0.989, 1.006] | 0.994 [0.985, 1.004] |
| all | user_ms | 0.999 [0.994, 1.005] | 0.998 [0.991, 1.005] |
| all | system_ms | 0.995 [0.963, 1.020] | 0.991 [0.963, 1.018] |
| all | peak_rss_mib | 0.997 [0.991, 1.003] | 0.998 [0.991, 1.003] |
| all | setup_ms | 0.997 [0.983, 1.017] | 0.997 [0.983, 1.017] |
| all | compile_layout_ms | 1.001 [0.994, 1.005] | 1.002 [0.984, 1.016] |
| all | render_ms | 1.057 [0.964, 1.169] | 1.049 [0.953, 1.158] |
| all | pipeline_ms | 1.001 [0.996, 1.005] | 0.999 [0.992, 1.005] |

## Per-case measurements

| Case | Baseline wall ms | Candidate wall ms | Wall ratio [95% CI] | CPU ratio [95% CI] | RSS ratio [95% CI] |
| --- | ---: | ---: | --- | --- | --- |
| private-0010 | 58.352 | 58.096 | 0.996 [0.987, 1.005] | 0.995 [0.981, 1.017] | 0.983 [0.972, 1.005] |
| private-0036 | 20.601 | 20.377 | 0.989 [0.968, 1.016] | 1.015 [0.968, 1.031] | 1.002 [0.993, 1.012] |
| private-0089 | 35.530 | 35.012 | 0.985 [0.968, 1.006] | 0.993 [0.973, 1.019] | 1.000 [0.991, 1.007] |
| private-0123 | 111.843 | 111.669 | 0.998 [0.994, 1.006] | 0.999 [0.993, 1.010] | 1.004 [0.968, 1.026] |
| private-0174 | 32.160 | 32.443 | 1.009 [0.990, 1.019] | 1.002 [0.981, 1.023] | 1.006 [0.996, 1.017] |
| private-0223 | 19.956 | 19.637 | 0.984 [0.969, 1.013] | 0.963 [0.946, 1.005] | 0.991 [0.984, 1.001] |

## Allocation counters

| Group | Counter | Baseline sum of medians | Candidate sum of medians | Ratio [95% CI] |
| --- | --- | ---: | ---: | --- |
| private | alloc_bytes | 61,919,624 | 60,850,728 | 0.983 [0.946, 1.037] |
| private | alloc_objects | 552,321 | 552,187 | 1.000 [1.000, 1.000] |
| private | gc_cycles | 14 | 13 | 0.929 [0.929, 1.000] |
| all | alloc_bytes | 61,919,624 | 60,850,728 | 0.983 [0.946, 1.037] |
| all | alloc_objects | 552,321 | 552,187 | 1.000 [1.000, 1.000] |
| all | gc_cycles | 14 | 13 | 0.929 [0.929, 1.000] |

Full stage, CPU, RSS, allocation, range, and IQR statistics are in public-summary.json. Private rows use opaque IDs.
