# Go A/B measurements

Comparison: incremental. 25 cases; 20 measured paired rounds; 3 allocation paired rounds.

All samples passed exit, timeout, paired-round, identity, and exact SVG checks. Only preflight-success cases in this selected run are represented; consult the local preflight report for excluded or failed cases.

Ratios are candidate / baseline; lower values indicate lower resource use. Brackets show 95% paired percentile bootstrap intervals (2,000 resamples; seed 20260914). Whole round blocks are shared across cases. Intervals are unadjusted for multiple comparisons and describe these fixed cases. An interval containing 1 is inconclusive. These results make no automatic keep/drop decision.

Allocation counters come from separate instrumented runs. Peak RSS is process memory. Public and private groups are reported separately; the all-cases result is descriptive and does not substitute for either group.

## Group wall time

| Group | Cases | Baseline total ms | Candidate total ms | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | ---: | ---: | ---: | --- | --- |
| public | 4 | 456.705 | 454.177 | 0.994 [0.989, 1.001] | 0.992 [0.986, 0.999] |
| private | 21 | 1,149.365 | 1,137.952 | 0.990 [0.986, 0.994] | 0.984 [0.979, 0.989] |
| all | 25 | 1,606.070 | 1,592.128 | 0.991 [0.987, 0.996] | 0.986 [0.981, 0.990] |

Totals above are sums of per-case medians; they are not one pooled median.

## Group CPU, memory, and pipeline stages

| Group | Metric | Ratio of sums of case medians [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | --- | --- |
| public | cpu_ms | 0.992 [0.985, 1.001] | 0.993 [0.984, 1.000] |
| public | user_ms | 0.998 [0.991, 1.002] | 0.998 [0.988, 1.002] |
| public | system_ms | 0.960 [0.942, 0.996] | 0.966 [0.946, 0.997] |
| public | peak_rss_mib | 0.992 [0.988, 0.997] | 0.992 [0.988, 0.997] |
| public | setup_ms | 0.972 [0.929, 1.045] | 0.972 [0.930, 1.044] |
| public | compile_layout_ms | 1.005 [0.998, 1.010] | 1.002 [0.997, 1.008] |
| public | render_ms | 0.818 [0.802, 0.842] | 0.805 [0.788, 0.831] |
| public | pipeline_ms | 0.999 [0.991, 1.002] | 0.996 [0.989, 0.999] |
| private | cpu_ms | 0.987 [0.982, 0.991] | 0.982 [0.974, 0.987] |
| private | user_ms | 0.988 [0.985, 0.992] | 0.981 [0.975, 0.986] |
| private | system_ms | 0.978 [0.961, 0.989] | 0.979 [0.961, 0.991] |
| private | peak_rss_mib | 0.985 [0.982, 0.988] | 0.985 [0.982, 0.987] |
| private | setup_ms | 0.998 [0.986, 1.011] | 0.997 [0.986, 1.011] |
| private | compile_layout_ms | 0.996 [0.994, 1.000] | 0.993 [0.989, 1.004] |
| private | render_ms | 0.811 [0.795, 0.829] | 0.791 [0.772, 0.812] |
| private | pipeline_ms | 0.987 [0.985, 0.990] | 0.971 [0.968, 0.976] |
| all | cpu_ms | 0.989 [0.984, 0.993] | 0.984 [0.976, 0.988] |
| all | user_ms | 0.991 [0.987, 0.994] | 0.984 [0.978, 0.988] |
| all | system_ms | 0.974 [0.961, 0.985] | 0.977 [0.962, 0.988] |
| all | peak_rss_mib | 0.986 [0.984, 0.988] | 0.986 [0.984, 0.988] |
| all | setup_ms | 0.997 [0.986, 1.011] | 0.993 [0.983, 1.010] |
| all | compile_layout_ms | 0.999 [0.996, 1.003] | 0.994 [0.991, 1.003] |
| all | render_ms | 0.813 [0.799, 0.828] | 0.793 [0.777, 0.812] |
| all | pipeline_ms | 0.991 [0.988, 0.993] | 0.975 [0.972, 0.979] |

## Tagged wall time

| Tag | Group | Cases | Ratio of totals [95% CI] | Equal-case geometric ratio [95% CI] |
| --- | --- | ---: | --- | --- |
| legend | public | 2 | 0.991 [0.979, 1.003] | 0.991 [0.979, 1.003] |
| legend | private | 1 | 0.972 [0.957, 0.986] | 0.972 [0.957, 0.986] |
| legend | all | 3 | 0.987 [0.977, 0.996] | 0.984 [0.976, 0.993] |
| markdown | public | 4 | 0.994 [0.989, 1.001] | 0.992 [0.986, 0.999] |
| markdown | private | 20 | 0.991 [0.986, 0.995] | 0.985 [0.979, 0.990] |
| markdown | all | 24 | 0.992 [0.988, 0.996] | 0.986 [0.981, 0.991] |

## Per-case measurements

| Case | Baseline wall ms | Candidate wall ms | Wall ratio [95% CI] | CPU ratio [95% CI] | RSS ratio [95% CI] |
| --- | ---: | ---: | --- | --- | --- |
| public/fulcro_rad | 107.750 | 106.252 | 0.986 [0.979, 1.002] | 0.991 [0.982, 1.007] | 0.981 [0.974, 0.993] |
| public/lion_reader_frontend | 86.921 | 86.275 | 0.993 [0.977, 1.009] | 0.994 [0.965, 1.010] | 0.995 [0.985, 1.003] |
| public/mocha_soc | 189.466 | 189.878 | 1.002 [0.991, 1.013] | 0.992 [0.981, 1.011] | 0.995 [0.980, 1.007] |
| public/spyre_encoder | 72.569 | 71.772 | 0.989 [0.973, 1.003] | 0.996 [0.972, 1.010] | 0.997 [0.987, 1.008] |
| private-0017 | 37.543 | 36.634 | 0.976 [0.963, 0.990] | 0.970 [0.941, 0.992] | 0.984 [0.968, 1.000] |
| private-0043 | 91.892 | 90.804 | 0.988 [0.978, 1.001] | 0.989 [0.978, 1.003] | 0.995 [0.990, 1.002] |
| private-0045 | 19.618 | 19.177 | 0.978 [0.958, 1.011] | 0.997 [0.958, 1.028] | 0.988 [0.972, 0.998] |
| private-0050 | 114.231 | 113.386 | 0.993 [0.983, 1.002] | 0.991 [0.985, 1.009] | 0.986 [0.974, 1.008] |
| private-0052 | 258.175 | 258.125 | 1.000 [0.989, 1.011] | 0.994 [0.987, 1.007] | 0.994 [0.980, 1.014] |
| private-0063 | 68.592 | 68.568 | 1.000 [0.988, 1.010] | 0.976 [0.963, 0.995] | 0.981 [0.966, 0.988] |
| private-0083 | 36.210 | 35.900 | 0.991 [0.973, 1.004] | 0.991 [0.969, 1.004] | 0.981 [0.973, 0.991] |
| private-0093 | 35.301 | 34.902 | 0.989 [0.965, 0.999] | 0.985 [0.967, 1.005] | 0.988 [0.981, 0.996] |
| private-0098 | 22.836 | 22.568 | 0.988 [0.943, 1.011] | 0.945 [0.899, 0.987] | 0.971 [0.958, 0.983] |
| private-0122 | 50.210 | 49.958 | 0.995 [0.978, 1.013] | 0.994 [0.963, 1.007] | 0.983 [0.961, 1.001] |
| private-0140 | 34.832 | 34.086 | 0.979 [0.968, 0.999] | 0.971 [0.955, 1.008] | 0.993 [0.985, 1.001] |
| private-0156 | 41.220 | 40.612 | 0.985 [0.971, 1.001] | 1.006 [0.977, 1.024] | 1.000 [0.987, 1.010] |
| private-0203 | 105.184 | 105.227 | 1.000 [0.991, 1.012] | 0.991 [0.983, 1.001] | 0.983 [0.967, 1.005] |
| private-0205 | 30.266 | 29.763 | 0.983 [0.963, 1.015] | 0.992 [0.970, 1.017] | 0.991 [0.985, 0.998] |
| private-0207 | 26.323 | 26.219 | 0.996 [0.946, 1.016] | 1.002 [0.949, 1.022] | 0.988 [0.978, 0.999] |
| private-0208 | 26.911 | 26.641 | 0.990 [0.971, 1.013] | 1.009 [0.973, 1.026] | 0.993 [0.981, 1.001] |
| private-0212 | 28.570 | 27.540 | 0.964 [0.938, 1.001] | 0.956 [0.921, 0.992] | 0.976 [0.970, 0.987] |
| private-0221 | 21.231 | 20.604 | 0.970 [0.941, 0.995] | 0.947 [0.906, 0.999] | 0.966 [0.953, 0.984] |
| private-0227 | 38.846 | 37.711 | 0.971 [0.953, 0.994] | 0.985 [0.965, 1.004] | 0.988 [0.977, 0.995] |
| private-0232 | 22.283 | 21.537 | 0.967 [0.924, 0.999] | 0.966 [0.896, 1.007] | 0.970 [0.960, 0.986] |
| private-0234 | 39.090 | 37.989 | 0.972 [0.957, 0.986] | 0.972 [0.943, 0.986] | 0.980 [0.971, 0.992] |

## Allocation counters

| Group | Counter | Baseline sum of medians | Candidate sum of medians | Ratio [95% CI] |
| --- | --- | ---: | ---: | --- |
| public | alloc_bytes | 100,644,408 | 98,665,056 | 0.980 [0.968, 0.981] |
| public | alloc_objects | 1,228,057 | 1,210,285 | 0.986 [0.985, 0.986] |
| public | gc_cycles | 25 | 23 | 0.920 [0.880, 0.960] |
| private | alloc_bytes | 285,541,344 | 268,960,576 | 0.942 [0.936, 0.950] |
| private | alloc_objects | 2,431,026 | 2,376,415 | 0.978 [0.977, 0.978] |
| private | gc_cycles | 61 | 57 | 0.934 [0.902, 0.934] |
| all | alloc_bytes | 386,185,752 | 367,625,632 | 0.952 [0.947, 0.955] |
| all | alloc_objects | 3,659,083 | 3,586,700 | 0.980 [0.980, 0.980] |
| all | gc_cycles | 86 | 80 | 0.930 [0.909, 0.933] |

Full stage, CPU, RSS, allocation, range, and IQR statistics are in public-summary.json. Private rows use opaque IDs.
